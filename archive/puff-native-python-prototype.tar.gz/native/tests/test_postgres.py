from dataclasses import replace
from decimal import Decimal
from pathlib import Path
import os
import tempfile
import threading
import time
import unittest
from puff.models import Profile,ConflictError
from puff.sql import ddl,ident
from puff.backup import backup,restore,pg_environment

@unittest.skipUnless(os.environ.get('PUFF_TEST_PG'),'Set PUFF_TEST_PG to an isolated test-cluster socket directory')
class PostgresTests(unittest.TestCase):
    def setUp(self):
        from puff.drivers.postgres import PostgresDriver
        self.profile=Profile(host=os.environ['PUFF_TEST_PG'],port=55439,user=os.environ['USER'],read_only=False,sslmode='disable')
        self.db=PostgresDriver(self.profile)
        self.db.execute('DROP TABLE IF EXISTS puff_native_test')
        self.db.execute(ddl('public','puff_native_test','create',columns=[dict(name='a',type='integer',primary=True),dict(name='b',type='text',primary=True),dict(name='value',type='numeric'),dict(name='data',type='jsonb')]))
        self.db.mutate('public','puff_native_test',[dict(kind='insert',values={'a':1,'b':'key','value':Decimal('0.12345678901234567890'),'data':{'x':1}}),dict(kind='insert',values={'a':2,'b':'key','value':2})])

    def tearDown(self):
        self.db.release()
        self.db.conn.execute('ROLLBACK')
        self.db.execute('DROP TABLE IF EXISTS puff_native_test')
        self.db.close()

    def test_composite_edits_rollback_schema_and_database(self):
        page=self.db.browse('public','puff_native_test')
        names=[c.name for c in page.columns]
        self.assertEqual(page.rows[0][2],Decimal('0.12345678901234567890'))
        original=dict(zip(names,page.rows[0]))
        self.db.mutate('public','puff_native_test',[dict(kind='update',original=original,values={'value':Decimal('3.5')})])
        with self.assertRaises(ConflictError):
            self.db.mutate('public','puff_native_test',[dict(kind='delete',original=original)])
        original['value']=Decimal('3.5')
        with self.assertRaises(Exception):
            self.db.mutate('public','puff_native_test',[dict(kind='update',original=original,values={'value':99}),dict(kind='insert',values={'a':2,'b':'key'})])
        self.assertEqual(self.db.browse('public','puff_native_test').rows[0][2],Decimal('3.5'))
        for action,kwargs in [('add',{'column':'extra','type':'integer'}),('rename',{'column':'extra','name':'renamed'}),('type',{'column':'renamed','type':'text'}),('drop',{'column':'renamed'})]:
            self.db.execute(ddl('public','puff_native_test',action,**kwargs))
        name='puff_native_"quoted'
        try:
            self.db.create_database(name)
            with self.assertRaises(Exception):
                self.db.create_database(name)
        finally:
            self.db.execute(f'DROP DATABASE IF EXISTS {ident(name)}')

    def test_streaming_and_cleanup(self):
        page=self.db.execute('SELECT n FROM generate_series(1,1000000) n')
        self.assertEqual(len(page.rows),200)
        self.assertTrue(page.more)
        self.assertEqual(self.db.fetch().rows[0][0],201)
        self.db.release()
        self.assertIsNone(self.db.stream)
        self.assertEqual(self.db.execute('SELECT 42').rows,[(42,)])
        self.assertIsNone(self.db.stream)
        with self.assertRaises(ValueError):
            self.db.execute("SELECT repeat('a',300000)")
        self.assertEqual(self.db.execute('SELECT 43').rows,[(43,)])

    def test_cancel_timeout_and_failure_recovery(self):
        errors=[]
        def query():
            try:
                self.db.execute('SELECT pg_sleep(20)')
            except Exception as exc:
                errors.append(exc)
        thread=threading.Thread(target=query)
        thread.start();time.sleep(.2);self.db.cancel();thread.join(4)
        self.assertFalse(thread.is_alive())
        self.assertEqual(errors[0].sqlstate,'57014')
        self.assertEqual(self.db.execute('SELECT 1').rows,[(1,)])
        self.db.conn.execute("SET statement_timeout='100ms'")
        with self.assertRaises(Exception) as error:
            self.db.execute('SELECT pg_sleep(2)')
        self.assertEqual(error.exception.sqlstate,'57014')
        self.db.conn.execute("SET statement_timeout='30s'")
        with self.assertRaises(Exception):
            self.db.execute('SELECT nonexistent FROM missing')
        self.assertEqual(self.db.execute('SELECT 1').rows,[(1,)])

    def test_readonly_and_authentication_tls_errors(self):
        from puff.drivers.postgres import PostgresDriver
        readonly=PostgresDriver(replace(self.profile,read_only=True))
        try:
            with self.assertRaises(Exception):
                readonly.execute('DELETE FROM puff_native_test')
        finally:
            readonly.close()
        self.db.conn.execute("DROP ROLE IF EXISTS puff_auth_test")
        self.db.conn.execute("CREATE ROLE puff_auth_test LOGIN PASSWORD 'correct'")
        try:
            with self.assertRaises(Exception) as auth:
                PostgresDriver(replace(self.profile,host='127.0.0.1',user='puff_auth_test',password='wrong'))
            self.assertIn('password authentication failed',str(auth.exception))
            with self.assertRaises(Exception) as tls:
                PostgresDriver(replace(self.profile,host='127.0.0.1',sslmode='require'))
            self.assertIn('SSL',str(tls.exception))
            with self.assertRaises(Exception):
                PostgresDriver(replace(self.profile,host='127.0.0.1',port=1))
        finally:
            self.db.conn.execute('DROP ROLE puff_auth_test')

    def test_backup_restore_roundtrip_and_collision_rollback(self):
        target='puff_native_restore'
        with tempfile.TemporaryDirectory() as temp:
            path=Path(temp)/'backup.dump'
            backup(self.profile,path)
            self.assertGreater(path.stat().st_size,0)
            self.db.create_database(target)
            try:
                p=replace(self.profile,database=target)
                with self.assertRaises(ValueError):
                    restore(p,path,'wrong')
                restore(p,path,target)
                from puff.drivers.postgres import PostgresDriver
                other=PostgresDriver(p)
                try:
                    self.assertEqual(len(other.browse('public','puff_native_test').rows),2)
                    with self.assertRaises(RuntimeError):
                        restore(p,path,target)
                    self.assertEqual(len(other.browse('public','puff_native_test').rows),2)
                finally:
                    other.close()
            finally:
                self.db.execute(f'DROP DATABASE {ident(target)}')

    def test_command_executes_once(self):
        self.db.execute("INSERT INTO puff_native_test(a,b) VALUES (3,'once')")
        self.assertEqual(self.db.execute("SELECT count(*) FROM puff_native_test WHERE a=3").rows,[(1,)])
