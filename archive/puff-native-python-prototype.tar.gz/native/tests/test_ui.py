"""Real GTK lifecycle tests. Opt-in because these require a display server."""
from pathlib import Path
from contextlib import closing
import os
import sqlite3
import tempfile
import time
import unittest

@unittest.skipUnless(os.environ.get('PUFF_TEST_UI')=='1','Set PUFF_TEST_UI=1 with a real or virtual display')
class UITests(unittest.TestCase):
    def test_native_workspace_dialogs_paging_edits_and_disconnect(self):
        import gi
        gi.require_version('Gtk','4.0');gi.require_version('Adw','1')
        from gi.repository import Gtk,GLib
        from puff.app import PuffApplication
        from puff.models import Profile
        from puff.dialogs import ConnectionDialog,SchemaDialog,CellDialog
        from puff.sql import ddl
        from decimal import Decimal
        with tempfile.TemporaryDirectory() as temp:
            previous=os.environ.get('XDG_CONFIG_HOME')
            os.environ['XDG_CONFIG_HOME']=temp
            path=Path(temp)/'database.sqlite'
            with closing(sqlite3.connect(path)) as db:
                db.execute('CREATE TABLE t(id INTEGER PRIMARY KEY,value TEXT)')
                db.executemany('INSERT INTO t VALUES (?,?)',[(i,f'row {i}') for i in range(1000)])
                db.commit()
            app=PuffApplication()
            self.assertTrue(app.register(None))
            app.activate()
            def spin(predicate,seconds=5):
                until=time.monotonic()+seconds
                while time.monotonic()<until:
                    while GLib.MainContext.default().pending():
                        GLib.MainContext.default().iteration(False)
                    if predicate():
                        return
                    time.sleep(.01)
                self.fail('Native UI timed out')
            try:
                self.assertEqual(app.tabs.get_n_pages(),0)
                profile=Profile(engine='sqlite',database=str(path),name='UI test',read_only=False)
                form=ConnectionDialog(app.window,app.store,app.connection_action,profile)
                form.present()
                app.connection_action(form,profile,'connect')
                spin(lambda:app.tabs.get_n_pages()==1)
                workspace=app.current()
                spin(lambda:not workspace.session.busy)
                self.assertEqual(workspace.loaded_schemas,['main'])
                workspace.browse('main','t')
                spin(lambda:not workspace.session.busy)
                self.assertEqual(len(workspace.results.rows),200)
                self.assertTrue(workspace.more)
                self.assertEqual(workspace.results.view.get_columns().get_n_items(),2)
                workspace.next()
                spin(lambda:not workspace.session.busy)
                self.assertEqual(workspace.results.rows[0][0],200)
                row=workspace.results.store.get_item(0)
                workspace.results.stage(row,1,'edited')
                self.assertEqual(workspace.results.edits[0]['value'],'edited')
                workspace.discard()
                self.assertFalse(workspace.results.edits)
                # Construct and exercise real schema and cell forms.
                schema=SchemaDialog(app.window,profile,['main'],workspace.results.columns,('main','t'),lambda *args:None)
                schema.present();schema.close()
                cell=CellDialog(app.window,workspace.results.columns[1],'original',lambda value:None)
                cell.present();cell.close()
                workspace.buffer.set_text('SELECT * FROM t')
                workspace.run()
                spin(lambda:not workspace.session.busy)
                self.assertEqual(len(workspace.results.rows),200)
                self.assertTrue(workspace.more)
                workspace.next()
                spin(lambda:not workspace.session.busy)
                self.assertEqual(workspace.results.rows[0][0],200)
                workspace.close_result()
                spin(lambda:not workspace.session.busy)
                self.assertFalse(workspace.results.rows)
                app.close_current()
                spin(lambda:app.tabs.get_n_pages()==0)
                workspace.session.thread.join(2)
                self.assertFalse(workspace.session.thread.is_alive())
                self.assertEqual(workspace.results.store.get_n_items(),0)
            finally:
                app.cleanup()
                app.window.destroy()
                if previous is None:
                    os.environ.pop('XDG_CONFIG_HOME',None)
                else:
                    os.environ['XDG_CONFIG_HOME']=previous
