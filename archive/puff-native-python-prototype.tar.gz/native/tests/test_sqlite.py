from pathlib import Path
import sqlite3
from contextlib import closing
import tempfile
import threading
import time
import unittest
from puff.models import Profile,ConflictError
from puff.drivers.sqlite import SQLiteDriver

class SQLiteTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory()
        self.path=Path(self.temp.name)/'sample.db'
        with closing(sqlite3.connect(self.path)) as conn:
            conn.executescript('CREATE TABLE t(a INTEGER,b TEXT,value TEXT,PRIMARY KEY(a,b)); INSERT INTO t VALUES (1,\'k\',\'original\'),(2,\'k\',\'other\');')
        self.profile=Profile(engine='sqlite',database=str(self.path),read_only=False)
        self.db=SQLiteDriver(self.profile)

    def tearDown(self):
        self.db.close()
        self.temp.cleanup()

    def test_streaming_readonly_transactions_conflicts(self):
        page=self.db.browse('main','t')
        self.assertEqual([c.name for c in page.columns if c.primary],['a','b'])
        original=dict(zip([c.name for c in page.columns],page.rows[0]))
        self.db.mutate('main','t',[dict(kind='update',original=original,values={'value':'changed'})])
        with self.assertRaises(ConflictError):
            self.db.mutate('main','t',[dict(kind='delete',original=original)])
        original['value']='changed'
        with self.assertRaises(sqlite3.IntegrityError):
            self.db.mutate('main','t',[dict(kind='update',original=original,values={'value':'rollback'}),dict(kind='insert',values={'a':2,'b':'k'})])
        self.assertEqual(self.db.browse('main','t').rows[0][2],'changed')
        self.db.execute('BEGIN')
        self.db.mutate('main','t',[dict(kind='delete',original=original)])
        self.db.execute('ROLLBACK')
        self.assertEqual(len(self.db.browse('main','t').rows),2)
        readonly=SQLiteDriver(Profile(engine='sqlite',database=str(self.path)))
        try:
            with self.assertRaises(sqlite3.OperationalError):
                readonly.execute('DELETE FROM t')
        finally:
            readonly.close()

    def test_large_result_and_cancellation(self):
        page=self.db.execute('WITH RECURSIVE n(x) AS (VALUES(1) UNION ALL SELECT x+1 FROM n WHERE x<100000) SELECT x FROM n')
        self.assertEqual(len(page.rows),200)
        self.assertTrue(page.more)
        self.assertEqual(self.db.fetch().rows[0][0],201)
        self.db.release()
        self.assertIsNone(self.db.cursor)
        cancelled=[]
        def run():
            db=SQLiteDriver(self.profile)
            self.active=db
            try:
                db.execute('WITH RECURSIVE n(x) AS (VALUES(1) UNION ALL SELECT x+1 FROM n WHERE x<1000000000) SELECT sum(x) FROM n')
            except sqlite3.OperationalError:
                cancelled.append(True)
            finally:
                db.close()
        thread=threading.Thread(target=run)
        thread.start()
        time.sleep(.1)
        self.active.cancel()
        thread.join(3)
        self.assertFalse(thread.is_alive())
        self.assertTrue(cancelled)

    def test_missing_file_does_not_create(self):
        with self.assertRaises(sqlite3.OperationalError):
            SQLiteDriver(Profile(engine='sqlite',database=str(self.path.parent/'missing.db')))
        self.assertFalse((self.path.parent/'missing.db').exists())
