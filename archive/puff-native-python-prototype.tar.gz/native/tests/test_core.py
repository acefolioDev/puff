import json
import os
from pathlib import Path
from decimal import Decimal
import tempfile
import threading
import time
import unittest
from puff.models import Profile
from puff.sql import ident,ddl,review_reason
from puff.store import Store
from puff.security import redact
from puff.export import export_page
from puff.drivers.results import page_rows
from puff.jobs import Session

class CoreTests(unittest.TestCase):
    def test_identifiers_and_review(self):
        self.assertEqual(ident('a";DROP TABLE x'), '"a"";DROP TABLE x"')
        for value in ('','a\0b','é'*32):
            with self.assertRaises(ValueError):
                ident(value)
        self.assertFalse(review_reason('SELECT 1'))
        for value in ('WITH x AS (DELETE FROM a RETURNING *) SELECT * FROM x','DELETE FROM x','SELECT 1; DROP TABLE x','SELECT * INTO y FROM x','EXPLAIN ANALYZE DELETE FROM x'):
            self.assertTrue(review_reason(value))

    def test_ddl(self):
        text=ddl('public','sample','create',columns=[dict(name='a',type='integer',primary=True),dict(name='b',type='text',primary=True)])
        self.assertIn('PRIMARY KEY ("a", "b")',text)
        for action in ('add','rename','type','drop'):
            self.assertIn('ALTER TABLE',ddl('public','x',action,column='a',name='b',type='text'))
        with self.assertRaises(ValueError):
            ddl('public','x','add',column='a',type='text;DROP TABLE y')

    def test_store_migration_secret_exclusion_permissions_and_bounds(self):
        with tempfile.TemporaryDirectory() as temp:
            root=Path(temp)
            store=Store(root/'metadata.sqlite3')
            p=Profile(password='topsecret')
            store.save(p)
            self.assertNotIn(b'topsecret',store.path.read_bytes())
            self.assertEqual(store.path.stat().st_mode & 0o777,0o600)
            self.assertEqual(root.stat().st_mode & 0o777,0o700)
            old=root/'connections.json'
            old.write_text(json.dumps([dict(id='legacy',name='Old',host='localhost',port=5432,user='postgres',database='postgres',password='nevercopy',ssl=True)]))
            store.migrate(old)
            migrated=next(p for p in store.profiles() if p.id=='legacy')
            self.assertEqual(migrated.sslmode,'verify-full')
            self.assertEqual(migrated.password,'')
            self.assertTrue(migrated.read_only)
            for i in range(205):
                store.record(p.id,f'SELECT {i}')
            self.assertEqual(len(store.history()),200)
            self.assertEqual(len(store.history('SELECT 204')),1)
            store.clear_history()
            self.assertEqual(store.history(),[])
            store.save_snippet('test','SELECT 1')
            self.assertEqual(store.snippets(),[('test','SELECT 1')])
            store.delete('legacy')
            self.assertEqual(len(store.profiles()),1)

    def test_redaction(self):
        text=redact("password=abc postgresql://armi:sekret@host failed p@ss",'p@ss')
        for value in ('abc','sekret','p@ss'):
            self.assertNotIn(value,text)
        self.assertNotIn('private',repr(Profile(password='private')))

    def test_result_bounds_and_export(self):
        page,pending=page_rows(iter((i,) for i in range(10000)),['n'])
        self.assertEqual(len(page.rows),200)
        self.assertTrue(page.more)
        self.assertEqual(pending,(200,))
        with self.assertRaises(ValueError):
            page_rows(iter([('a'*300000,)]),['large'])
        with tempfile.TemporaryDirectory() as temp:
            path=Path(temp)/'data.json'
            export_page(path,['x','x'],[(Decimal('0.12345678901234567890'),None)],'json')
            self.assertEqual(json.loads(path.read_text())['rows'][0][0],'0.12345678901234567890')
            export_page(Path(temp)/'data.csv',['x'],[('a,b\nc',)],'csv')
            self.assertEqual(path.stat().st_mode & 0o777,0o600)

    def test_session_bounds_and_cleanup(self):
        deliveries=[]
        p=Profile(password='private')
        s=Session(p,deliveries.append)
        gate=threading.Event()
        self.assertTrue(s.submit(lambda _:gate.wait(1),lambda result,error:None))
        self.assertFalse(s.submit(lambda _:None,lambda *args:None))
        s.close()
        gate.set()
        s.thread.join(2)
        self.assertFalse(s.thread.is_alive())
        self.assertEqual(p.password,'')
        self.assertFalse(deliveries)

if __name__=='__main__':
    unittest.main()
