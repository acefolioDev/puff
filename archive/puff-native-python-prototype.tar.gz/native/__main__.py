from puff.app import main
raise SystemExit(main())
