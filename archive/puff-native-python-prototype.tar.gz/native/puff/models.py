from dataclasses import dataclass, field
from typing import Any
import uuid

PAGE_ROWS = 200
PAGE_BYTES = 4 * 1024 * 1024
CELL_BYTES = 256 * 1024
MAX_SESSIONS = 4

@dataclass
class Profile:
    id: str = field(default_factory=lambda: str(uuid.uuid4()))
    name: str = "Local PostgreSQL"
    engine: str = "postgres"
    host: str = "localhost"
    port: int = 5432
    user: str = "postgres"
    database: str = "postgres"
    sslmode: str = "prefer"
    environment: str = "development"
    group: str = "Local"
    read_only: bool = True
    timeout: int = 30
    password: str = field(default="", repr=False, compare=False)
    remember: bool = False

    def validate(self):
        if self.engine not in ("postgres", "sqlite"):
            raise ValueError("Unsupported database driver")
        if not self.name.strip() or not self.database.strip():
            raise ValueError("A profile name and database are required")
        if self.engine == "postgres" and (not self.host or not self.user or not 1 <= self.port <= 65535):
            raise ValueError("Check host, username and port")
        if not 1 <= self.timeout <= 3600:
            raise ValueError("Query timeout must be between 1 and 3600 seconds")
        if self.sslmode not in ("disable", "prefer", "require", "verify-full"):
            raise ValueError("Invalid TLS mode")
        if self.environment not in ("development", "staging", "production"):
            raise ValueError("Invalid environment")

@dataclass
class Column:
    name: str
    type: str
    primary: bool = False
    generated: bool = False
    nullable: bool = True

@dataclass
class Page:
    columns: list[str]
    rows: list[tuple[Any, ...]]
    more: bool = False
    ms: float = 0
    message: str = ""

@dataclass
class TablePage:
    columns: list[Column]
    rows: list[tuple[Any, ...]]
    more: bool

class ConflictError(RuntimeError):
    pass
