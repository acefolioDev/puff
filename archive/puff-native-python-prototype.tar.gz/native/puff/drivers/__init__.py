"""Drivers load only when a user opens a connection."""
def connect(profile):
    profile.validate()
    if profile.engine == "postgres":
        from .postgres import PostgresDriver
        return PostgresDriver(profile)
    if profile.engine == "sqlite":
        from .sqlite import SQLiteDriver
        return SQLiteDriver(profile)
    raise ValueError("Unsupported driver")
