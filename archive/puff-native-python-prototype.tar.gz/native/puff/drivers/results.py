import time
from ..models import PAGE_ROWS, PAGE_BYTES, CELL_BYTES, Page

def page_rows(iterator, columns, pending=None):
    """One bounded page plus one look-ahead row. Never retain previous pages."""
    start = time.monotonic()
    rows, size = [], 0
    more = False
    while len(rows) < PAGE_ROWS:
        try:
            row = pending if pending is not None else next(iterator)
            pending = None
        except StopIteration:
            break
        widths = [len(str(v).encode()) if v is not None else 0 for v in row]
        if any(n > CELL_BYTES for n in widths):
            raise ValueError("A cell exceeds 256 KiB. Select a substring or export with pg_dump instead.")
        width = sum(widths)
        if size + width > PAGE_BYTES and rows:
            pending, more = row, True
            break
        rows.append(tuple(row))
        size += width
    else:
        try:
            pending = next(iterator)
            more = True
        except StopIteration:
            pass
    return Page(columns, rows, more, (time.monotonic()-start)*1000), pending
