import time
import uuid
import psycopg
from psycopg.types.json import Jsonb
from ..models import Column, ConflictError, Page, TablePage, PAGE_ROWS
from ..sql import ident, qualified
from .results import page_rows

class PostgresDriver:
    def __init__(self, profile):
        self.profile = profile
        self.conn = psycopg.connect(host=profile.host, port=profile.port, user=profile.user, password=profile.password, dbname=profile.database, sslmode=profile.sslmode, connect_timeout=5, client_encoding="UTF8", autocommit=True, application_name="My Puff", options=f"-c statement_timeout={profile.timeout*1000} -c lock_timeout=5000 -c default_transaction_read_only={'on' if profile.read_only else 'off'}")
        self.cursor = None
        self.stream = None
        self.pending = None
        self.result_columns = []

    def release(self):
        if self.stream is not None:
            self.stream.close()  # psycopg cancels/drains incomplete streaming results
            self.stream = None
        if self.cursor:
            self.cursor.close()
            self.cursor = None
        self.pending = None

    def close(self):
        # Closing the socket first avoids waiting for a slow stream to drain.
        self.conn.close()
        self.release()

    def cancel(self):
        if not self.conn.closed:
            self.conn.cancel_safe(timeout=2)

    def execute(self, text, params=()):
        if not text.strip() or len(text.encode()) > 1000000:
            raise ValueError("Enter one statement, maximum 1 MiB")
        self.release()
        start = time.monotonic()
        self.cursor = self.conn.cursor()
        self.stream = self.cursor.stream(text, params or None)
        result = self.fetch()
        result.ms = (time.monotonic()-start)*1000
        return result

    def fetch(self):
        if self.stream is None:
            raise ValueError("No more results")
        # Description becomes available on the first streamed row.
        try:
            if self.pending is None:
                try:
                    self.pending = next(self.stream)
                except StopIteration:
                    self.result_columns = [c.name for c in self.cursor.description or []]
                    self.release()
                    return Page(self.result_columns, [], False, message="Query completed; no further rows")
            self.result_columns = [c.name for c in self.cursor.description or []]
            result, self.pending = page_rows(self.stream, self.result_columns, self.pending)
            if not result.more:
                self.release()
            return result
        except psycopg.ProgrammingError as error:
            # stream() runs commands exactly once, then reports lack of rowset.
            if error.sqlstate is None and "didn't produce a result" in str(error):
                self.release()
                return Page([], [], message="Command completed")
            self.release()
            raise
        except Exception:
            self.release()
            raise

    def _rows(self, text, params=()):
        self.release()
        # Only fixed bounded metadata queries use execute/fetchall.
        with self.conn.cursor() as cur:
            cur.execute(text, params or None)
            return cur.fetchall()

    def schemas(self):
        return [r[0] for r in self._rows("SELECT nspname FROM pg_namespace WHERE nspname NOT LIKE 'pg\\_%' ESCAPE '\\' AND nspname <> 'information_schema' ORDER BY 1 LIMIT 500")]

    def tables(self, schema):
        return self._rows("SELECT c.relname,c.relkind::text FROM pg_class c JOIN pg_namespace n ON n.oid=c.relnamespace WHERE n.nspname=%s AND c.relkind IN ('r','p','v','m') ORDER BY 1 LIMIT 1000", (schema,))

    def columns(self, schema, table):
        return [Column(*r) for r in self._rows("SELECT a.attname,format_type(a.atttypid,a.atttypmod),EXISTS(SELECT 1 FROM pg_index i WHERE i.indrelid=c.oid AND i.indisprimary AND a.attnum=ANY(i.indkey)),(a.attgenerated<>'' OR a.attidentity<>''),NOT a.attnotnull FROM pg_attribute a JOIN pg_class c ON c.oid=a.attrelid JOIN pg_namespace n ON n.oid=c.relnamespace WHERE n.nspname=%s AND c.relname=%s AND a.attnum>0 AND NOT a.attisdropped ORDER BY a.attnum LIMIT 500", (schema, table))]

    def browse(self, schema, table, offset=0):
        if not isinstance(offset, int) or offset < 0 or offset > 100000000:
            raise ValueError("Invalid offset")
        columns = self.columns(schema, table)
        keys = [ident(c.name) for c in columns if c.primary]
        order = " ORDER BY " + ','.join(keys) if keys else ""
        rows = self._rows(f"SELECT * FROM {qualified(schema,table)}{order} LIMIT %s OFFSET %s", (PAGE_ROWS+1, offset))
        # Validate row/cell size with the same page budget as raw queries.
        page, _ = page_rows(iter(rows[:PAGE_ROWS]), [c.name for c in columns])
        if len(page.rows) != min(PAGE_ROWS,len(rows)):
            raise ValueError("Table page exceeds 4 MiB; select narrower columns in SQL workspace")
        return TablePage(columns, page.rows, len(rows)>PAGE_ROWS)

    def mutate(self, schema, table, changes):
        if self.profile.read_only:
            raise PermissionError("Connection is read-only")
        if not changes or len(changes)>PAGE_ROWS:
            raise ValueError("Use a batch of 1–200 changes")
        columns = self.columns(schema,table)
        writable = {c.name:c for c in columns if not c.generated}
        keys = [c.name for c in columns if c.primary]
        target = qualified(schema,table)
        def adapt(name,value):
            return Jsonb(value) if value is not None and writable[name].type in ('json','jsonb') else value
        with self.conn.transaction():
            with self.conn.cursor() as cur:
                for change in changes:
                    entries = list(change.get('values',{}).items())
                    if any(k not in writable for k,v in entries):
                        raise ValueError("Invalid writable column")
                    values = [adapt(k,v) for k,v in entries]
                    kind = change['kind']
                    if kind == 'insert':
                        query = f"INSERT INTO {target} ({','.join(ident(k) for k,v in entries)}) VALUES ({','.join(['%s']*len(entries))})" if entries else f"INSERT INTO {target} DEFAULT VALUES"
                    else:
                        original = change.get('original',{})
                        if not keys or any(k not in original or original[k] is None for k in keys):
                            raise ValueError("A complete primary key is required")
                        if any(c.name not in original for c in columns):
                            raise ValueError("Original row is incomplete")
                        if kind == 'update' and entries:
                            query = f"UPDATE {target} SET " + ','.join(f'{ident(k)}=%s' for k,v in entries)
                        elif kind == 'delete':
                            query = f"DELETE FROM {target}"
                            values = []
                        else:
                            raise ValueError("Invalid mutation")
                        predicates = []
                        for c in columns:
                            raw=original[c.name]
                            values.append(Jsonb(raw) if raw is not None and c.type in ('json','jsonb') else raw)
                            predicates.append(f"to_jsonb({ident(c.name)}) IS NOT DISTINCT FROM to_jsonb(%s::{c.type})")
                        query += ' WHERE ' + ' AND '.join(predicates)
                    cur.execute(query, values or None)
                    if cur.rowcount != 1:
                        raise ConflictError("Row changed or disappeared; reload before saving")

    def create_database(self, name):
        if self.profile.read_only:
            raise PermissionError("Connection is read-only")
        self.release()
        self.conn.execute(f'CREATE DATABASE {ident(name)}')

    def inspect(self, schema, table):
        return self.execute("SELECT 'constraint' AS kind,conname AS name,pg_get_constraintdef(oid) AS definition FROM pg_constraint WHERE conrelid=%s::regclass UNION ALL SELECT 'index',indexname,indexdef FROM pg_indexes WHERE schemaname=%s AND tablename=%s", (qualified(schema,table),schema,table))
