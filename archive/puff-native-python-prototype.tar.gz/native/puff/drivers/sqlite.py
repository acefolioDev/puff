from pathlib import Path
import sqlite3
import time
from ..models import Column, ConflictError, TablePage, PAGE_ROWS
from ..sql import ident, qualified
from .results import page_rows

class SQLiteDriver:
    def __init__(self, profile):
        self.profile = profile
        path = Path(profile.database).expanduser().resolve()
        # Opening a connection never silently creates a misspelled database.
        mode = 'ro' if profile.read_only else 'rw'
        self.conn = sqlite3.connect(path.as_uri()+'?mode='+mode, uri=True, timeout=5, isolation_level=None)
        self.conn.execute('PRAGMA foreign_keys=ON')
        if profile.read_only:
            self.conn.execute('PRAGMA query_only=ON')
        self.cursor = None
        self.pending = None
        self.deadline = 0
        self.conn.set_progress_handler(self._progress, 1000)

    def _progress(self):
        return int(bool(self.deadline and time.monotonic()>self.deadline))

    def release(self):
        if self.cursor:
            self.cursor.close()
        self.cursor = None
        self.pending = None
        self.deadline = 0

    def close(self):
        self.release()
        self.conn.close()

    def cancel(self):
        self.conn.interrupt()

    def execute(self, text, params=()):
        if not text.strip() or len(text.encode())>1000000:
            raise ValueError('Enter one statement, maximum 1 MiB')
        self.release()
        start=time.monotonic()
        self.deadline=start+self.profile.timeout
        self.cursor=self.conn.execute(text, params)
        return self.fetch()

    def fetch(self):
        if not self.cursor:
            raise ValueError('No more results')
        try:
            names=[c[0] for c in self.cursor.description or []]
            page,self.pending=page_rows(iter(self.cursor),names,self.pending)
            if not names:
                page.message=f'Command completed ({self.cursor.rowcount} affected)'
            if not page.more:
                self.release()
            return page
        except Exception:
            self.release()
            raise

    def schemas(self):
        return ['main']

    def tables(self, schema):
        if schema!='main':
            raise ValueError('Only the main database is browsed')
        return self.conn.execute("SELECT name,type FROM sqlite_schema WHERE type IN ('table','view') AND name NOT LIKE 'sqlite_%' ORDER BY name LIMIT 1000").fetchall()

    def columns(self, schema, table):
        if schema!='main':
            raise ValueError('Unknown schema')
        return [Column(r[1],r[2] or 'text',bool(r[5]),bool(r[6]),not bool(r[3])) for r in self.conn.execute(f'PRAGMA table_xinfo({ident(table)})').fetchmany(500)]

    def browse(self,schema,table,offset=0):
        if not isinstance(offset,int) or not 0<=offset<=100000000:
            raise ValueError('Invalid offset')
        columns=self.columns(schema,table)
        keys=[ident(c.name) for c in columns if c.primary]
        order=' ORDER BY '+','.join(keys) if keys else ''
        cursor=self.conn.execute(f'SELECT * FROM {qualified(schema,table)}{order} LIMIT ? OFFSET ?',(PAGE_ROWS+1,offset))
        rows=cursor.fetchmany(PAGE_ROWS+1)
        cursor.close()
        page,_=page_rows(iter(rows[:PAGE_ROWS]),[c.name for c in columns])
        if len(page.rows)!=min(PAGE_ROWS,len(rows)):
            raise ValueError('Table page exceeds 4 MiB; select narrower columns')
        return TablePage(columns,page.rows,len(rows)>PAGE_ROWS)

    def mutate(self,schema,table,changes):
        if self.profile.read_only:
            raise PermissionError('Connection is read-only')
        if not changes or len(changes)>PAGE_ROWS:
            raise ValueError('Use a batch of 1–200 changes')
        self.release()
        columns=self.columns(schema,table)
        names={c.name for c in columns if not c.generated}
        keys=[c.name for c in columns if c.primary]
        target=qualified(schema,table)
        # SAVEPOINT works both inside and outside a user-managed transaction.
        self.conn.execute('SAVEPOINT puff_edit')
        try:
            for change in changes:
                entries=list(change.get('values',{}).items())
                if any(k not in names for k,v in entries):
                    raise ValueError('Invalid writable column')
                values=[v for k,v in entries]
                if change['kind']=='insert':
                    query=f"INSERT INTO {target} ({','.join(ident(k) for k,v in entries)}) VALUES ({','.join(['?']*len(entries))})" if entries else f'INSERT INTO {target} DEFAULT VALUES'
                else:
                    original=change.get('original',{})
                    if not keys or any(original.get(k) is None for k in keys) or any(c.name not in original for c in columns):
                        raise ValueError('A complete primary key and original row are required')
                    if change['kind']=='update' and entries:
                        query=f"UPDATE {target} SET "+','.join(f'{ident(k)}=?' for k,v in entries)
                    elif change['kind']=='delete':
                        query=f'DELETE FROM {target}'
                        values=[]
                    else:
                        raise ValueError('Invalid mutation')
                    query+=' WHERE '+' AND '.join(f'{ident(c.name)} IS ?' for c in columns)
                    values.extend(original[c.name] for c in columns)
                if self.conn.execute(query,values).rowcount!=1:
                    raise ConflictError('Row changed or disappeared; reload before saving')
            self.conn.execute('RELEASE puff_edit')
        except Exception:
            self.conn.execute('ROLLBACK TO puff_edit')
            self.conn.execute('RELEASE puff_edit')
            raise

    def inspect(self,schema,table):
        return self.execute('SELECT type,name,sql FROM sqlite_schema WHERE tbl_name=? ORDER BY type,name LIMIT 500',(table,))
