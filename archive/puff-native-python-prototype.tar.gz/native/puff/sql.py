"""Small explicit SQL builders. SQL text is never used as an authorization boundary."""
import re

TYPES = ("text", "varchar(255)", "integer", "bigint", "numeric", "boolean", "uuid", "date", "timestamp", "timestamptz", "jsonb", "bytea")

def ident(value: str) -> str:
    if not isinstance(value, str) or not value or "\0" in value or len(value.encode()) > 63:
        raise ValueError("Invalid identifier (1–63 UTF-8 bytes required)")
    return '"' + value.replace('"', '""') + '"'

def qualified(schema, table):
    return f"{ident(schema)}.{ident(table)}"

def datatype(value):
    if value not in TYPES:
        raise ValueError("Unsupported data type")
    return value

def ddl(schema, table, action, *, columns=(), column="", name="", type="text"):
    target = qualified(schema, table)
    if action == "create":
        if not columns or len(columns) > 100:
            raise ValueError("Specify 1–100 columns")
        if len({c['name'] for c in columns}) != len(columns):
            raise ValueError("Column names must be unique")
        fields = [f"{ident(c['name'])} {datatype(c['type'])}" + (" NOT NULL" if not c.get('nullable', True) else "") for c in columns]
        primary = [ident(c['name']) for c in columns if c.get('primary')]
        if primary:
            fields.append(f"PRIMARY KEY ({', '.join(primary)})")
        return f"CREATE TABLE {target} ({', '.join(fields)})"
    if action == "add":
        return f"ALTER TABLE {target} ADD COLUMN {ident(column)} {datatype(type)}"
    if action == "rename":
        return f"ALTER TABLE {target} RENAME COLUMN {ident(column)} TO {ident(name)}"
    if action == "type":
        return f"ALTER TABLE {target} ALTER COLUMN {ident(column)} TYPE {datatype(type)} USING {ident(column)}::{datatype(type)}"
    if action == "drop":
        return f"ALTER TABLE {target} DROP COLUMN {ident(column)}"
    raise ValueError("Unsupported schema operation")

def review_reason(text: str) -> str:
    # Deliberately conservative. Server read-only permissions enforce safety.
    # Comments, CTEs, dollar quotes, functions and multiple statements get review.
    clean = text.strip().rstrip(';').strip()
    if not re.match(r"^(SELECT|SHOW|VALUES|EXPLAIN)\b", clean, re.I):
        return "This statement may modify data or database structure."
    if re.search(r"\b(DROP|TRUNCATE|DELETE|UPDATE|INSERT|ALTER|CREATE|COPY|CALL|DO|ANALYZE|INTO|FOR\s+UPDATE)\b|--|/\*|;|\$", clean, re.I):
        return "Review this potentially modifying or expensive statement."
    return ""
