"""One native query tab and one bounded database worker per workspace."""
import gi
gi.require_version('Gtk','4.0')
gi.require_version('Adw','1')
gi.require_version('GtkSource','5')
from gi.repository import Gtk, Adw, GtkSource, Gio, GLib, GObject
from .widgets import ResultView,button,padded
from .dialogs import Form,CellDialog,SchemaDialog,confirm
from .models import Column,PAGE_ROWS
from .sql import ident,review_reason
from . import backup as backups
from .export import export_page
from .security import redact
import json

class TableItem(GObject.Object):
    def __init__(self,name,kind):
        super().__init__()
        self.name=name
        self.kind=kind

class Workspace(Gtk.Box):
    def __init__(self,window,session,store):
        super().__init__(orientation=Gtk.Orientation.VERTICAL)
        self.window=window
        self.session=session
        self.profile=session.profile
        self.store=store
        self.table=None
        self.offset=0
        self.more=False
        self.closed=False
        self.loaded_schemas=[]
        self.completion_names=set()
        self.split=Gtk.Paned(orientation=Gtk.Orientation.HORIZONTAL,position=230,vexpand=True)
        self.split.set_shrink_start_child(False)
        self.sidebar=Gtk.Box(orientation=Gtk.Orientation.VERTICAL,spacing=6)
        self.sidebar.set_size_request(210,-1)
        self.sidebar.append(padded(Gtk.Label(label=f'{self.profile.group} · {self.profile.environment.upper()}',xalign=0),12))
        self.sidebar.append(button('Reload schemas',self.load_schemas))
        self.schema_box=Gtk.Box(orientation=Gtk.Orientation.VERTICAL,spacing=3)
        sidebar_scroll=Gtk.ScrolledWindow(vexpand=True)
        sidebar_scroll.set_child(self.schema_box)
        self.sidebar.append(sidebar_scroll)
        self.split.set_start_child(self.sidebar)
        body=Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        controls=padded(Gtk.Box(spacing=6),8)
        self.run_button=button('Run  Ctrl+Enter',self.run,'suggested-action')
        self.cancel_button=button('Cancel',self.cancel)
        self.cancel_button.set_sensitive(False)
        controls.append(self.run_button)
        controls.append(self.cancel_button)
        controls.append(Gtk.Label(label='Read-only' if self.profile.read_only else 'Writable',hexpand=True,xalign=1))
        menu=Gtk.MenuButton(icon_name='view-more-symbolic',tooltip_text='Database tools')
        popover=Gtk.Popover()
        tool_box=padded(Gtk.Box(orientation=Gtk.Orientation.VERTICAL,spacing=4),6)
        tools=[('Create database',self.create_database),('Create table',lambda:self.schema_dialog(False)),('Manage columns',lambda:self.schema_dialog(True)),('Inspect constraints / indexes',self.inspect_table),('BEGIN transaction',lambda:self.execute_sql('BEGIN')),('Commit transaction',lambda:self.execute_sql('COMMIT')),('Rollback transaction',lambda:self.execute_sql('ROLLBACK')),('EXPLAIN current SQL',self.explain),('Open SQL file',self.open_sql),('History and snippets',self.history),('Save SQL snippet',self.snippet),('Export page as CSV',lambda:self.export('csv')),('Export page as JSON',lambda:self.export('json')),('Backup PostgreSQL',self.backup),('Restore PostgreSQL archive',self.restore),('Active sessions (on demand)',lambda:self.execute_sql('SELECT pid,usename,state,wait_event_type,wait_event,query_start FROM pg_stat_activity WHERE datname=current_database() LIMIT 200')),('Locks (on demand)',lambda:self.execute_sql('SELECT pid,locktype,mode,granted FROM pg_locks LIMIT 200'))]
        for label,callback in tools:
            b=button(label,lambda cb=callback:(popover.popdown(),cb()))
            b.set_has_frame(False)
            tool_box.append(b)
        popover.set_child(tool_box)
        menu.set_popover(popover)
        controls.append(menu)
        self.history_enabled=Gtk.CheckButton(label='Save SQL history',tooltip_text='Opt in: SQL may contain sensitive literal values. Last 200 statements are stored locally.')
        controls.append(self.history_enabled)
        body.append(controls)
        editor_split=Gtk.Paned(orientation=Gtk.Orientation.VERTICAL,position=240,vexpand=True)
        self.buffer=GtkSource.Buffer()
        self.buffer.set_language(GtkSource.LanguageManager.get_default().get_language('sql'))
        self.buffer.set_highlight_syntax(True)
        self.buffer.set_text('SELECT current_database(), current_user;' if self.profile.engine=='postgres' else 'SELECT sqlite_version();')
        self.editor=GtkSource.View.new_with_buffer(self.buffer)
        self.editor.set_show_line_numbers(True)
        self.editor.set_monospace(True)
        self.editor.set_auto_indent(True)
        self.editor.set_tab_width(4)
        self.editor.set_top_margin(12)
        self.editor.set_bottom_margin(12)
        self.words_buffer=GtkSource.Buffer()
        self.words_buffer.set_text('SELECT FROM WHERE ORDER BY GROUP LIMIT OFFSET INSERT INTO VALUES UPDATE SET DELETE JOIN LEFT RIGHT NULL TRUE FALSE CREATE ALTER TABLE INDEX BEGIN COMMIT ROLLBACK EXPLAIN')
        self.words=GtkSource.CompletionWords.new('SQL and loaded metadata')
        self.words.register(self.words_buffer)
        self.editor.get_completion().add_provider(self.words)
        editor_scroll=Gtk.ScrolledWindow()
        editor_scroll.set_child(self.editor)
        editor_split.set_start_child(editor_scroll)
        lower=Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        self.table_controls=padded(Gtk.Box(spacing=6),6)
        self.table_label=Gtk.Label(label='Query results',hexpand=True,xalign=0)
        self.table_controls.append(self.table_label)
        self.add_button=button('Add row',self.insert_row)
        self.save_button=button('Save edits',self.save_edits,'suggested-action')
        self.delete_button=button('Delete selected',self.delete_rows)
        for b in (self.add_button,self.save_button,self.delete_button):
            self.table_controls.append(b)
        self.discard_button=button('Discard',self.discard)
        self.table_controls.append(self.discard_button)
        lower.append(self.table_controls)
        self.results=ResultView(self.edit_cell)
        lower.append(self.results)
        pages=padded(Gtk.Box(spacing=8),6)
        self.prev_button=button('Previous',self.previous)
        self.next_button=button('Next page',self.next)
        self.release_button=button('Close result',self.close_result)
        self.page_label=Gtk.Label(label='200 rows per page · sorting/filtering applies to this page',hexpand=True,xalign=0)
        pages.append(self.prev_button)
        pages.append(self.next_button)
        pages.append(self.release_button)
        pages.append(self.page_label)
        lower.append(pages)
        editor_split.set_end_child(lower)
        body.append(editor_split)
        self.status=Gtk.Label(label='Connected',xalign=0,wrap=True,selectable=True)
        self.status.set_margin_start(12)
        self.status.set_margin_end(12)
        self.status.set_margin_top(6)
        self.status.set_margin_bottom(6)
        body.append(self.status)
        self.split.set_end_child(body)
        self.append(self.split)
        self.update_buttons()
        GLib.idle_add(lambda:(self.load_schemas(),False)[1])

    def update_buttons(self):
        busy=self.session.busy
        writable=not self.profile.read_only
        self.run_button.set_sensitive(not busy)
        self.cancel_button.set_sensitive(busy)
        self.next_button.set_sensitive(not busy and self.more and not self.results.edits)
        self.prev_button.set_sensitive(not busy and bool(self.table) and self.offset>0 and not self.results.edits)
        self.add_button.set_sensitive(not busy and bool(self.table) and writable and not self.results.edits)
        self.save_button.set_sensitive(not busy and bool(self.results.edits) and writable)
        self.delete_button.set_sensitive(not busy and bool(self.table) and writable and any(c.primary for c in self.results.columns))
        self.discard_button.set_sensitive(not busy and bool(self.results.edits))

    def job(self,work,done=None,message='Working…'):
        if self.closed:
            return
        def delivered(result,error):
            if self.closed:
                return
            self.status.remove_css_class('error')
            if error:
                self.status.set_text(error)
                self.status.add_css_class('error')
            else:
                self.status.set_text('Completed')
                try:
                    if done:
                        done(result)
                except Exception as exc:
                    self.status.set_text(redact(exc,self.profile.password))
            self.update_buttons()
        if self.session.submit(work,delivered):
            self.status.set_text(message)
        else:
            self.status.set_text('An operation is already running in this tab. Cancel it or use another tab.')
        self.update_buttons()

    def cancel(self):
        self.session.cancel()
        self.status.set_text('Cancellation requested…')

    def check_dirty(self,callback):
        if self.results.edits:
            confirm(self.window,'Discard unsaved changes?','Your staged cell edits have not been saved.','Discard',lambda:(self.discard(),callback()))
        else:
            callback()

    def discard(self):
        self.results.edits.clear()
        for i in range(self.results.store.get_n_items()):
            row=self.results.store.get_item(i)
            self.results.store.splice(i,1,[row])
        self.update_buttons()

    def load_schemas(self):
        if self.closed:
            return
        def loaded(schemas):
            self.loaded_schemas=schemas
            child=self.schema_box.get_first_child()
            while child:
                next_child=child.get_next_sibling()
                self.schema_box.remove(child)
                child=next_child
            for name in schemas:
                expander=Gtk.Expander(label=name)
                expander.connect('notify::expanded',self.expand_schema,name)
                self.schema_box.append(expander)
        self.job(lambda s:s.driver.schemas(),loaded,'Loading schemas…')

    def expand_schema(self,expander,_,schema):
        if not expander.get_expanded() or expander.get_child():
            return
        def loaded(tables):
            model=Gio.ListStore.new(TableItem)
            model.splice(0,0,[TableItem(*row) for row in tables])
            selection=Gtk.SingleSelection.new(model)
            factory=Gtk.SignalListItemFactory()
            factory.connect('setup',lambda _,item:item.set_child(Gtk.Label(xalign=0,margin_start=16,margin_top=6,margin_bottom=6)))
            factory.connect('bind',lambda _,item:item.get_child().set_text(item.get_item().name+('  ◇' if item.get_item().kind in ('v','m','view') else '')))
            view=Gtk.ListView.new(selection,factory)
            view.connect('activate',lambda _,pos:self.browse(schema,model.get_item(pos).name))
            expander.set_child(view)
            self.add_words([name for name,kind in tables])
            if len(tables)==1000:
                self.status.set_text('Explorer capped at 1,000 tables per schema. Use SQL for the remainder.')
        self.job(lambda s:s.driver.tables(schema),loaded,'Loading tables…')

    def add_words(self,names):
        self.completion_names.update(names)
        self.completion_names=set(sorted(self.completion_names)[:1500])
        text='SELECT FROM WHERE JOIN ORDER BY GROUP LIMIT OFFSET INSERT UPDATE DELETE CREATE ALTER TABLE INDEX BEGIN COMMIT ROLLBACK NULL '+' '.join(self.completion_names)
        self.words_buffer.set_text(text)

    def sql_text(self):
        selection=self.buffer.get_selection_bounds()
        start,end=selection if selection else self.buffer.get_bounds()
        return self.buffer.get_text(start,end,False)

    def run(self):
        self.execute_sql(self.sql_text())

    def execute_sql(self,text):
        def execute():
            self.table=None
            self.offset=0
            self.more=False
            def complete(page):
                self.show_query(page)
                if self.history_enabled.get_active():
                    self.store.record(self.profile.id,text)
            self.job(lambda s:s.driver.execute(text),complete,'Executing query…')
        def reviewed():
            reason=review_reason(text)
            if reason or self.profile.environment=='production':
                confirm(self.window,'Review SQL',f'{reason}\n\n{text[:12000]}','Execute',execute,self.profile.database if self.profile.environment=='production' else None)
            else:
                execute()
        self.check_dirty(reviewed)

    def show_query(self,page):
        self.results.set_page(page.columns,page.rows)
        self.more=page.more
        self.table_label.set_text('Query results')
        self.status.set_text(page.message or f'{len(page.rows)} rows · {page.ms:.1f} ms · '+('more available' if page.more else 'complete'))
        self.page_label.set_text('Next replaces this page. Sorting and filtering apply to the current page.')

    def browse(self,schema,table,offset=0):
        def run():
            def loaded(page):
                self.table=(schema,table)
                self.offset=offset
                self.more=page.more
                self.results.set_page([c.name for c in page.columns],page.rows,page.columns)
                self.table_label.set_text(f'{schema}.{table}')
                self.page_label.set_text(f'Rows {offset+1}–{offset+len(page.rows)} · page size {PAGE_ROWS}')
                self.status.set_text('Double-click a cell to stage an edit' if any(c.primary for c in page.columns) else 'No primary key: updates and deletes disabled')
                self.add_words([c.name for c in page.columns])
            def work(s):
                s.driver.release()
                return s.driver.browse(schema,table,offset)
            self.job(work,loaded,'Loading table page…')
        self.check_dirty(run)

    def next(self):
        if self.table:
            self.browse(*self.table,self.offset+PAGE_ROWS)
        else:
            self.job(lambda s:s.driver.fetch(),self.show_query,'Fetching next page…')

    def previous(self):
        if self.table:
            self.browse(*self.table,max(0,self.offset-PAGE_ROWS))

    def close_result(self):
        def close():
            self.job(lambda s:s.driver.release(),lambda _:(self.results.clear(),setattr(self,'more',False),setattr(self,'table',None)))
        self.check_dirty(close)

    def edit_cell(self,row,index):
        if not self.table or self.profile.read_only or self.session.busy or not any(c.primary for c in self.results.columns):
            return
        column=self.results.columns[index]
        if column.generated:
            self.status.set_text('Generated columns cannot be edited')
            return
        value=self.results.edits.get(row.index,{}).get(column.name,row.values[index])
        def staged(value):
            self.results.stage(row,index,value)
            self.update_buttons()
            self.status.set_text('Cell staged. Save edits to commit the batch.')
        CellDialog(self.window,column,value,staged).present()

    def original(self,row):
        return dict(zip(self.results.names,row))

    def write_review(self,title,body,callback):
        if self.profile.read_only:
            self.status.set_text('This connection is read-only. Reconnect with read-only disabled to write.')
            return
        confirm(self.window,title,body,'Apply',callback,self.profile.database if self.profile.environment=='production' else None)

    def save_edits(self):
        if not self.table or not self.results.edits:
            return
        changes=[dict(kind='update',original=self.original(self.results.rows[i]),values=values) for i,values in self.results.edits.items()]
        schema,table=self.table
        def saved(_):
            self.results.edits.clear()
            self.browse(schema,table,self.offset)
        self.write_review('Save staged changes?',f'Update {len(changes)} rows in {schema}.{table}. The complete batch succeeds or rolls back.',lambda:self.job(lambda s:s.driver.mutate(schema,table,changes),saved))

    def delete_rows(self):
        if not self.table:
            return
        rows=self.results.selected()
        if not rows:
            self.status.set_text('Select rows first (Ctrl/Shift click)')
            return
        if self.results.edits:
            self.status.set_text('Save or discard cell edits before deleting rows')
            return
        schema,table=self.table
        changes=[dict(kind='delete',original=self.original(row.values)) for row in rows]
        self.write_review('Delete selected rows?',f'Permanently delete {len(rows)} rows from {schema}.{table}.',lambda:self.job(lambda s:s.driver.mutate(schema,table,changes),lambda _:self.browse(schema,table,self.offset)))

    def insert_row(self):
        if not self.table or self.profile.read_only:
            return
        form=Form(self.window,'Insert row')
        form.note('Enter a JSON object of column names and values. Omit generated/default fields. This insertion commits immediately outside an explicit transaction.')
        values=form.entry('JSON object','{}')
        schema,table=self.table
        def insert():
            data=json.loads(values.get_text())
            if not isinstance(data,dict):
                raise ValueError('Enter a JSON object')
            def apply():
                form.set_busy(True)
                def done(result,error):
                    form.report(error)
                    if not error:
                        form.close()
                        self.browse(schema,table,self.offset)
                if not self.session.submit(lambda s:s.driver.mutate(schema,table,[dict(kind='insert',values=data)]),done):
                    form.report('A database operation is already running')
            self.write_review('Insert a row?',f'Insert one row into {schema}.{table}.',apply)
        form.submit('Review insertion',insert)
        form.present()

    def schema_dialog(self,existing):
        if self.profile.read_only:
            self.status.set_text('Reconnect with read-only disabled to change schema')
            return
        if existing and not self.table:
            self.status.set_text('Open a table first')
            return
        def show():
            def apply(form,text):
                form.set_busy(True)
                def done(result,error):
                    form.report(error)
                    if not error:
                        form.close()
                        self.load_schemas()
                        self.results.clear()
                        self.table=None
                        self.more=False
                if not self.session.submit(lambda s:s.driver.execute(text),done):
                    form.report('A database operation is already running')
            SchemaDialog(self.window,self.profile,self.loaded_schemas,self.results.columns,self.table if existing else None,apply).present()
        self.check_dirty(show)

    def create_database(self):
        if self.profile.engine!='postgres' or self.profile.read_only:
            self.status.set_text('Database creation requires a writable PostgreSQL connection')
            return
        form=Form(self.window,'Create database')
        name=form.entry('Database name')
        form.note('Your PostgreSQL role needs CREATEDB. The current connection stays open; connect to the new database in another tab.')
        def review():
            value=name.get_text()
            statement='CREATE DATABASE '+ident(value)
            def apply():
                form.set_busy(True)
                def done(result,error):
                    form.report(error)
                    if not error:
                        form.close()
                        self.status.set_text(f'Database {value} created. Use Connect to open it.')
                if not self.session.submit(lambda s:s.driver.create_database(value),done):
                    form.report('An operation is running')
            self.write_review('Create database?',statement,apply)
        form.submit('Review SQL',review)
        form.present()

    def inspect_table(self):
        if not self.table:
            self.status.set_text('Open a table first')
            return
        schema,table=self.table
        self.check_dirty(lambda:self.job(lambda s:s.driver.inspect(schema,table),lambda page:(setattr(self,'table',None),self.show_query(page))))

    def explain(self):
        text=self.sql_text()
        self.execute_sql(('EXPLAIN (FORMAT JSON) ' if self.profile.engine=='postgres' else 'EXPLAIN QUERY PLAN ')+text)

    def open_sql(self):
        dialog=Gtk.FileDialog(title='Open SQL file')
        def opened(dialog,result):
            try:
                path=dialog.open_finish(result).get_path()
                def load(s):
                    from pathlib import Path
                    if Path(path).stat().st_size>1000000:
                        raise ValueError('SQL files are limited to 1 MiB')
                    return Path(path).read_text()
                self.check_dirty(lambda:self.job(load,lambda text:self.buffer.set_text(text)))
            except GLib.Error:
                pass
        dialog.open(self.window,None,opened)

    def export(self,format):
        columns=list(self.results.names)
        rows=list(self.results.rows)
        if not columns:
            self.status.set_text('No result page to export')
            return
        dialog=Gtk.FileDialog(title='Export current page only',initial_name=f'puff-page.{format}')
        def saved(dialog,result):
            try:
                path=dialog.save_finish(result).get_path()
                self.job(lambda s:export_page(path,columns,rows,format),lambda _:self.status.set_text(f'Exported {len(rows)} rows from current page'))
            except GLib.Error:
                pass
        dialog.save(self.window,None,saved)

    def backup(self):
        if self.profile.engine!='postgres':
            self.status.set_text('Native archive backup is currently PostgreSQL-only')
            return
        dialog=Gtk.FileDialog(title='Create PostgreSQL custom archive',initial_name='puff-backup.dump')
        def saved(dialog,result):
            try:
                path=dialog.save_finish(result).get_path()
                self.job(lambda s:backups.backup(self.profile,path,s.cancel_event),lambda _:self.status.set_text('Backup completed and archive structure verified. Test a restore before relying on it.'),'Creating backup…')
            except GLib.Error:
                pass
        dialog.save(self.window,None,saved)

    def restore(self):
        if self.profile.engine!='postgres' or self.profile.read_only:
            self.status.set_text('Restore requires a writable PostgreSQL connection')
            return
        dialog=Gtk.FileDialog(title='Choose PostgreSQL custom archive')
        def opened(dialog,result):
            try:
                path=dialog.open_finish(result).get_path()
                confirm(self.window,'Restore into '+self.profile.database+'?',f'Target: {self.profile.host}:{self.profile.port}/{self.profile.database}\nRestore creates objects and inserts data. Existing conflicting objects cause failure. A single transaction rolls back on error. Prefer an empty test database first.','Restore',lambda:self.job(lambda s:backups.restore(self.profile,path,self.profile.database,s.cancel_event),lambda _:self.status.set_text('Restore completed successfully'),'Restoring archive…'),self.profile.database)
            except GLib.Error:
                pass
        dialog.open(self.window,None,opened)

    def history(self):
        form=Form(self.window,'History and snippets')
        form.note('History is opt-in per tab. SQL can contain sensitive data. Stored locally, maximum 200 queries and 100 snippets.')
        search=form.entry('Search history')
        box=Gtk.Box(orientation=Gtk.Orientation.VERTICAL,spacing=4)
        form.add(box)
        def reload(*_):
            child=box.get_first_child()
            while child:
                nxt=child.get_next_sibling();box.remove(child);child=nxt
            entries=[(created,text) for text,created in self.store.history(search.get_text())]+self.store.snippets()
            for label,text in entries:
                box.append(button(label+' · '+text[:70].replace('\n',' '),lambda text=text:(self.buffer.set_text(text),form.close())))
        search.connect('activate',reload)
        form.add(button('Search',reload))
        form.add(button('Clear history',lambda:(self.store.clear_history(),reload())))
        reload()
        form.present()

    def snippet(self):
        form=Form(self.window,'Save SQL snippet')
        name=form.entry('Snippet name')
        text=self.sql_text()
        def save():
            if not name.get_text().strip():
                raise ValueError('Enter a name')
            self.store.save_snippet(name.get_text(),text)
            form.close()
        form.submit('Save snippet',save)
        form.present()

    def dispose_workspace(self):
        self.closed=True
        self.results.dispose_results()
        self.words.unregister(self.words_buffer)
        self.session.close()
