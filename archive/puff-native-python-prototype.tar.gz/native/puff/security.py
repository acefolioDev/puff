import re
from .models import Profile

def redact(message, *secrets):
    text = str(message)
    for secret in secrets:
        if secret:
            text = text.replace(secret, "[redacted]")
    text = re.sub(r"(?i)(password\s*[=:]\s*)(?:'[^']*'|\"[^\"]*\"|\S+)", r"\1[redacted]", text)
    return re.sub(r"(postgres(?:ql)?://[^:/\s]+:)[^@\s]+@", r"\1[redacted]@", text)

class SecretStore:
    """Synchronous calls belong on a worker; the OS handles unlock prompts."""
    def __init__(self):
        import gi
        gi.require_version("Secret", "1")
        from gi.repository import Secret
        self.api = Secret
        self.schema = Secret.Schema.new("io.github.puff.Connection", Secret.SchemaFlags.NONE, {"profile": Secret.SchemaAttributeType.STRING})

    def get(self, profile_id):
        return self.api.password_lookup_sync(self.schema, {"profile": profile_id}, None) or ""

    def save(self, p: Profile):
        if not self.api.password_store_sync(self.schema, {"profile": p.id}, self.api.COLLECTION_DEFAULT, f"My Puff: {p.name}", p.password, None):
            raise RuntimeError("The desktop secret service did not save the password")

    def remove(self, profile_id):
        self.api.password_clear_sync(self.schema, {"profile": profile_id}, None)
