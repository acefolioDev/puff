import gi
gi.require_version('Gtk','4.0')
gi.require_version('Adw','1')
from gi.repository import Gtk,Adw,Gio,GLib
from dataclasses import replace
from . import __version__
from .models import MAX_SESSIONS
from .store import Store
from .jobs import Session
from .dialogs import ConnectionDialog,confirm
from .widgets import button
from .workspace import Workspace

class PuffApplication(Adw.Application):
    def __init__(self):
        super().__init__(application_id='io.github.puff.Puff',flags=Gio.ApplicationFlags.NON_UNIQUE)
        self.window=None
        self.sessions=set()
        self.retiring=[]
        self.store=None
        self.quitting=False
        self.connect('activate',self.activate_window)
        self.connect('shutdown',lambda *_:self.cleanup())

    def activate_window(self,*_):
        if self.window:
            self.window.present()
            return
        self.store=Store()
        self.window=Adw.ApplicationWindow(application=self,title='My Puff',default_width=1200,default_height=780)
        self.window.set_icon_name('puff')
        self.window.connect('close-request',self.close_window)
        root=Adw.ToolbarView()
        header=Adw.HeaderBar()
        header.set_title_widget(Adw.WindowTitle(title='My Puff',subtitle='Native database workspace'))
        header.pack_start(button('Connect',self.connection,'suggested-action'))
        header.pack_start(button('Disconnect tab',self.close_current))
        self.style_manager=Adw.StyleManager.get_default()
        appearance=Gtk.MenuButton(icon_name='open-menu-symbolic',tooltip_text='Appearance')
        menu=Gio.Menu()
        for label,name in [('System appearance','system'),('Light appearance','light'),('Dark appearance','dark')]:
            action=Gio.SimpleAction.new('theme-'+name,None)
            action.connect('activate',lambda a,p,n=name:self.set_theme(n))
            self.add_action(action)
            menu.append(label,'app.theme-'+name)
        appearance.set_menu_model(menu)
        header.pack_end(appearance)
        root.add_top_bar(header)
        self.tabs=Adw.TabView()
        self.tabs.connect('close-page',self.close_page)
        self.tabbar=Adw.TabBar(view=self.tabs,autohide=True)
        root.add_top_bar(self.tabbar)
        self.empty=Adw.StatusPage(title='Your databases, a little lighter.',description='Connect to PostgreSQL or an existing SQLite file. No database connections open until you choose one.',icon_name='database-symbolic')
        self.empty.set_child(button('Connect to a database',self.connection,'suggested-action'))
        self.stack=Gtk.Stack()
        self.stack.add_named(self.empty,'empty')
        self.stack.add_named(self.tabs,'tabs')
        self.stack.set_visible_child_name('empty')
        root.set_content(self.stack)
        self.window.set_content(root)
        for name,callback,accel in [('connect',self.connection,'<Control>n'),('new-tab',self.duplicate,'<Control>t'),('close-tab',self.close_current,'<Control>w'),('run',lambda:self.current() and self.current().run(),'<Control>Return'),('cancel',lambda:self.current() and self.current().cancel(),'<Control>period')]:
            action=Gio.SimpleAction.new(name,None)
            action.connect('activate',lambda a,p,cb=callback:cb())
            self.add_action(action)
            self.set_accels_for_action('app.'+name,[accel])
        self.window.present()

    def set_theme(self,name):
        schemes={'system':Adw.ColorScheme.DEFAULT,'light':Adw.ColorScheme.FORCE_LIGHT,'dark':Adw.ColorScheme.FORCE_DARK}
        self.style_manager.set_color_scheme(schemes[name])

    def current(self):
        page=self.tabs.get_selected_page()
        return page.get_child() if page else None

    def duplicate(self):
        current=self.current()
        self.connection(replace(current.profile,password='') if current else None)

    def connection(self,initial=None):
        ConnectionDialog(self.window,self.store,self.connection_action,initial).present()

    def connection_action(self,form,profile,action):
        if len(self.sessions)>=MAX_SESSIONS:
            form.report('At most four concurrent workspaces/connection operations. Disconnect a tab first.')
            return
        form.set_busy(True)
        session=Session(profile,GLib.idle_add)
        self.sessions.add(session)
        def work(s):
            from .security import SecretStore
            saved=next((p for p in self.store.profiles() if p.id==profile.id),None)
            if action=='delete':
                if saved and saved.remember:
                    SecretStore().remove(profile.id)
                self.store.delete(profile.id)
                return 'Profile and saved credential removed'
            if profile.remember and not profile.password:
                profile.password=SecretStore().get(profile.id)
            if action in ('test','connect'):
                from .drivers import connect
                s.driver=connect(profile)
            if action in ('save','connect'):
                if profile.remember:
                    SecretStore().save(profile)
                elif saved and saved.remember:
                    SecretStore().remove(profile.id)
                self.store.save(profile)
            return 'Connection successful' if action=='test' else 'Profile saved'
        def done(result,error):
            form.report(error or result)
            if error or action!='connect':
                session.close()
                self.sessions.discard(session)
                self.retiring.append(session)
                if action=='delete' and not error:
                    form.close()
                return
            form.close()
            workspace=Workspace(self.window,session,self.store)
            page=self.tabs.append(workspace)
            page.set_title(f'{profile.name} · {profile.database} [{profile.environment}]')
            self.tabs.set_selected_page(page)
            self.stack.set_visible_child_name('tabs')
        session.submit(work,done)

    def close_current(self):
        page=self.tabs.get_selected_page()
        if page:
            self.tabs.close_page(page)

    def close_page(self,view,page):
        workspace=page.get_child()
        def finish():
            workspace.dispose_workspace()
            self.sessions.discard(workspace.session)
            self.retiring.append(workspace.session)
            view.close_page_finish(page,True)
            if view.get_n_pages()==0:
                self.stack.set_visible_child_name('empty')
        if workspace.results.edits or workspace.session.busy:
            dialog=Adw.MessageDialog(transient_for=self.window,heading='Disconnect this tab?',body='Unsaved edits will be discarded. Running work is cancelled. Open transactions roll back on disconnect; already committed changes remain.')
            dialog.add_response('cancel','Keep tab')
            dialog.add_response('close','Disconnect')
            dialog.set_close_response('cancel')
            dialog.connect('response',lambda _,response:finish() if response=='close' else view.close_page_finish(page,False))
            dialog.present()
        else:
            finish()
        return True

    def close_window(self,*_):
        if self.quitting:
            return False
        has_work=any(self.tabs.get_nth_page(i).get_child().results.edits or self.tabs.get_nth_page(i).get_child().session.busy for i in range(self.tabs.get_n_pages()))
        if has_work:
            confirm(self.window,'Quit My Puff?','Discard staged edits, cancel running work, and disconnect all tabs? Open transactions roll back; committed changes remain.','Quit',self.finish_quit)
            return True
        self.cleanup()
        return False

    def finish_quit(self):
        self.quitting=True
        self.cleanup()
        self.window.destroy()

    def cleanup(self):
        for session in list(self.sessions):
            session.close()
        for session in list(self.sessions)+self.retiring:
            session.thread.join(timeout=6)
        self.sessions.clear()
        self.retiring.clear()


def main():
    import os,sys
    os.umask(0o077)
    return PuffApplication().run(sys.argv)
