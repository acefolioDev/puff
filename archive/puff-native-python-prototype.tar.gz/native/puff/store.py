"""Private, bounded local metadata; passwords never enter SQLite."""
from contextlib import contextmanager
from dataclasses import asdict, fields
from pathlib import Path
import json
import os
import sqlite3
from .models import Profile

class Store:
    def __init__(self, path=None):
        root = Path(os.environ.get("XDG_CONFIG_HOME", Path.home() / ".config")) / "puff"
        self.path = Path(path) if path else root / "workspace.sqlite3"
        self.path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
        self.path.parent.chmod(0o700)
        fd = os.open(self.path, os.O_RDWR | os.O_CREAT | os.O_NOFOLLOW, 0o600)
        os.close(fd)
        self.path.chmod(0o600)
        with self.open() as db:
            db.executescript("CREATE TABLE IF NOT EXISTS profiles(id TEXT PRIMARY KEY, data TEXT NOT NULL); CREATE TABLE IF NOT EXISTS history(id INTEGER PRIMARY KEY, profile TEXT, sql TEXT, created TEXT DEFAULT CURRENT_TIMESTAMP); CREATE TABLE IF NOT EXISTS snippets(name TEXT PRIMARY KEY, sql TEXT NOT NULL);")
        if not path:
            self.migrate(root / "connections.json")

    @contextmanager
    def open(self):
        db = sqlite3.connect(self.path)
        try:
            with db:
                yield db
        finally:
            db.close()

    def profiles(self):
        with self.open() as db:
            return [Profile(**json.loads(row[0])) for row in db.execute("SELECT data FROM profiles ORDER BY json_extract(data, '$.group'), json_extract(data, '$.name')")]

    def save(self, p):
        p.validate()
        data = asdict(p)
        data.pop("password", None)
        with self.open() as db:
            db.execute("INSERT OR REPLACE INTO profiles VALUES (?,?)", (p.id, json.dumps(data)))

    def delete(self, profile_id):
        with self.open() as db:
            db.execute("DELETE FROM profiles WHERE id=?", (profile_id,))
            db.execute("DELETE FROM history WHERE profile=?", (profile_id,))

    def migrate(self, path):
        # Add missing legacy IDs only. Never copy legacy passwords or modify input.
        if not path.exists():
            return
        known = {p.id for p in self.profiles()}
        allowed = {f.name for f in fields(Profile)} - {"password", "ssl"}
        for data in json.loads(path.read_text())[:200]:
            if data.get("id") in known:
                continue
            clean = {k:v for k,v in data.items() if k in allowed}
            clean['sslmode'] = 'verify-full' if data.get('ssl') else 'disable'
            self.save(Profile(**clean))

    def history(self, search=""):
        with self.open() as db:
            return list(db.execute("SELECT sql,created FROM history WHERE sql LIKE ? ORDER BY id DESC LIMIT 200", ('%' + search + '%',)))

    def record(self, profile, text):
        with self.open() as db:
            db.execute("INSERT INTO history(profile,sql) VALUES (?,?)", (profile, text[:100000]))
            db.execute("DELETE FROM history WHERE id NOT IN (SELECT id FROM history ORDER BY id DESC LIMIT 200)")

    def clear_history(self):
        with self.open() as db:
            db.execute("DELETE FROM history")

    def snippets(self):
        with self.open() as db:
            return list(db.execute("SELECT name, sql FROM snippets ORDER BY name LIMIT 100"))

    def save_snippet(self, name, text):
        with self.open() as db:
            count = db.execute("SELECT COUNT(*) FROM snippets").fetchone()[0]
            if count >= 100 and not db.execute("SELECT 1 FROM snippets WHERE name=?", (name,)).fetchone():
                raise ValueError("Snippet limit is 100")
            db.execute("INSERT OR REPLACE INTO snippets VALUES (?,?)", (name[:100], text[:100000]))
