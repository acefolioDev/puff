"""CSV and JSON export of the current bounded page, with atomic replacement."""
import csv
import json
import os
import tempfile
from pathlib import Path
from decimal import Decimal
from datetime import date,datetime
import uuid

def json_value(value):
    if isinstance(value,(date,datetime,Decimal,uuid.UUID)):
        return str(value)
    if isinstance(value,(bytes,memoryview)):
        return bytes(value).hex()
    raise TypeError(f'Unsupported value: {type(value).__name__}')

def export_page(path,columns,rows,format):
    path=Path(path)
    fd,temp=tempfile.mkstemp(prefix='.puff-export-',dir=path.parent)
    try:
        with os.fdopen(fd,'w',newline='',encoding='utf-8') as stream:
            if format=='csv':
                writer=csv.writer(stream)
                writer.writerow(columns)
                writer.writerows(rows)
            elif format=='json':
                # Array records preserve duplicate SQL column names.
                json.dump({'columns':columns,'rows':rows},stream,default=json_value,ensure_ascii=False)
            else:
                raise ValueError('Unknown export format')
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temp,path)
    finally:
        if os.path.exists(temp):
            os.unlink(temp)
