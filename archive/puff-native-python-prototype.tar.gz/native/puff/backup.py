"""Native utility invocation without shell strings or password arguments."""
from contextlib import contextmanager
from pathlib import Path
import os
import shutil
import subprocess
import tempfile
from .security import redact

@contextmanager
def pg_environment(profile):
    with tempfile.TemporaryDirectory(prefix='puff-auth-') as root:
        path=Path(root)/'pgpass'
        def escaped(v):
            return str(v).replace('\\','\\\\').replace(':','\\:')
        if '\n' in profile.password or '\r' in profile.password:
            raise ValueError('Passwords containing newlines cannot be used with pgpass')
        path.write_text(':'.join(escaped(v) for v in [profile.host,profile.port,profile.database,profile.user,profile.password])+'\n')
        path.chmod(0o600)
        env={k:v for k,v in os.environ.items() if not k.startswith('PG')}
        env.update(PGPASSFILE=str(path),PGSSLMODE=profile.sslmode,PGCONNECT_TIMEOUT='5')
        yield env

def utility(name):
    path=shutil.which(name)
    if not path:
        raise FileNotFoundError(f'Install the PostgreSQL client tools; {name} was not found')
    return path

def run(args,env,password,cancel_event=None):
    # stderr is spooled to disk, not an unbounded in-memory pipe. Runtime bounded.
    with tempfile.TemporaryFile() as errors:
        import time
        process=subprocess.Popen(args,env=env,stdin=subprocess.DEVNULL,stdout=subprocess.DEVNULL,stderr=errors)
        start=time.monotonic()
        try:
            while process.poll() is None:
                if cancel_event is not None and cancel_event.is_set():
                    raise RuntimeError('Backup/restore cancelled; restore transaction is rolled back')
                if time.monotonic()-start>600:
                    raise TimeoutError('Backup/restore exceeded 10 minutes')
                try:
                    process.wait(timeout=0.2)
                except subprocess.TimeoutExpired:
                    pass
        finally:
            if process.poll() is None:
                process.terminate()
                try:
                    process.wait(timeout=3)
                except subprocess.TimeoutExpired:
                    process.kill()
                    process.wait()
        if process.returncode:
            errors.seek(0)
            raise RuntimeError(redact(errors.read(8192).decode(errors='replace'),password) or f'Utility exited {process.returncode}')

def backup(profile,destination,cancel_event=None):
    if profile.engine!='postgres':
        raise ValueError('Use SQLite database file backup tooling for SQLite; this workflow supports PostgreSQL')
    destination=Path(destination)
    fd,temp=tempfile.mkstemp(prefix='.puff-backup-',dir=destination.parent)
    os.close(fd)
    try:
        with pg_environment(profile) as env:
            args=[utility('pg_dump'),'-h',profile.host,'-p',str(profile.port),'-U',profile.user,'-d',profile.database,'--format=custom','--compress=6','--file',temp]
            run(args,env,profile.password,cancel_event)
            # Verify archive structure before publishing it. This is not a full restore test.
            run([utility('pg_restore'),'--list',temp],env,profile.password,cancel_event)
        if not os.path.getsize(temp):
            raise RuntimeError('Backup archive is empty')
        os.replace(temp,destination)
    finally:
        if os.path.exists(temp):
            os.unlink(temp)

def restore(profile,source,confirmed_database,cancel_event=None):
    if profile.read_only:
        raise PermissionError('Connection is read-only')
    if confirmed_database!=profile.database:
        raise ValueError('The confirmation must match the target database exactly')
    source=Path(source).resolve(strict=True)
    if profile.engine!='postgres':
        raise ValueError('This restore workflow supports PostgreSQL custom archives')
    with pg_environment(profile) as env:
        run([utility('pg_restore'),'--list',str(source)],env,profile.password,cancel_event)
        # No --clean/--create: avoid silently replacing existing objects. Atomic restore.
        run([utility('pg_restore'),'-h',profile.host,'-p',str(profile.port),'-U',profile.user,'-d',profile.database,'--exit-on-error','--single-transaction','--no-owner',str(source)],env,profile.password,cancel_event)
