import gi
gi.require_version('Gtk','4.0')
gi.require_version('Adw','1')
from gi.repository import Gtk, Adw
from .widgets import button,padded
from .models import Profile
from .sql import TYPES,ddl
from dataclasses import replace
import json
from decimal import Decimal

class Form(Adw.Window):
    def __init__(self,parent,title):
        super().__init__(transient_for=parent,modal=True,title=title,default_width=560,default_height=500)
        self.busy=False
        self.last_field=None
        self.connect('close-request',lambda *_:self.busy)
        view=Adw.ToolbarView()
        view.add_top_bar(Adw.HeaderBar())
        self.box=padded(Gtk.Box(orientation=Gtk.Orientation.VERTICAL,spacing=12),20)
        scroll=Gtk.ScrolledWindow(vexpand=True)
        scroll.set_policy(Gtk.PolicyType.NEVER,Gtk.PolicyType.AUTOMATIC)
        scroll.set_child(self.box)
        view.set_content(scroll)
        self.set_content(view)
        self.error=Gtk.Label(wrap=True,xalign=0,selectable=True)
        self.error.add_css_class('error')
        self.actions=Gtk.Box(spacing=8,halign=Gtk.Align.END)
        self.box.append(self.error)
        self.box.append(self.actions)
        self.actions.append(button('Cancel',lambda:self.close()))

    def note(self,text):
        self.add(Gtk.Label(label=text,wrap=True,xalign=0))

    def add(self,widget):
        self.box.insert_child_after(widget,self.last_field)
        self.last_field=widget
        return widget

    def entry(self,label,value='',password=False):
        box=Gtk.Box(orientation=Gtk.Orientation.VERTICAL,spacing=5)
        box.append(Gtk.Label(label=label,xalign=0))
        entry=Gtk.PasswordEntry(show_peek_icon=True) if password else Gtk.Entry()
        entry.set_text(str(value))
        entry.set_hexpand(True)
        box.append(entry)
        self.add(box)
        return entry

    def combo(self,label,options,value=None):
        box=Gtk.Box(orientation=Gtk.Orientation.VERTICAL,spacing=5)
        box.append(Gtk.Label(label=label,xalign=0))
        drop=Gtk.DropDown.new_from_strings(options)
        drop.set_selected(options.index(value) if value in options else 0)
        box.append(drop)
        self.add(box)
        return drop

    def check(self,label,value=False):
        widget=Gtk.CheckButton(label=label,active=value)
        self.add(widget)
        return widget

    def set_busy(self,value):
        self.busy=value
        self.actions.set_sensitive(not value)
        if value:
            self.error.set_text('Working…')

    def report(self,error):
        self.set_busy(False)
        self.error.set_text(error or '')

    def submit(self,label,fn):
        def run():
            try:
                fn()
            except Exception as exc:
                self.report(str(exc))
        self.actions.append(button(label,run,'suggested-action'))


def combo_text(drop):
    return drop.get_selected_item().get_string()


def confirm(parent,title,body,action,callback,target=None):
    dialog=Adw.MessageDialog(transient_for=parent,heading=title,body=body)
    dialog.add_response('cancel','Cancel')
    dialog.add_response('apply',action)
    dialog.set_response_appearance('apply',Adw.ResponseAppearance.DESTRUCTIVE)
    dialog.set_default_response('cancel')
    dialog.set_close_response('cancel')
    if target is not None:
        entry=Gtk.Entry(placeholder_text=f'Type {target} to confirm')
        dialog.set_extra_child(entry)
        dialog.set_response_enabled('apply',False)
        entry.connect('changed',lambda e:dialog.set_response_enabled('apply',e.get_text()==target))
    def respond(_,response):
        if response=='apply':
            callback()
    dialog.connect('response',respond)
    dialog.present()

class ConnectionDialog(Form):
    def __init__(self,parent,store,connect_callback,initial=None):
        super().__init__(parent,'Connect to a database')
        self.store=store
        self.parent=parent
        self.callback=connect_callback
        self.profile=initial or Profile()
        self.saved=store.profiles()
        saved=self.combo('Saved profiles',['New connection']+[f'{p.group} / {p.name}' for p in self.saved])
        self.name=self.entry('Profile name',self.profile.name)
        self.engine=self.combo('Database engine',['postgres','sqlite'],self.profile.engine)
        self.group=self.entry('Project or group',self.profile.group)
        self.environment=self.combo('Environment',['development','staging','production'],self.profile.environment)
        self.host=self.entry('Host or Unix socket directory',self.profile.host)
        self.port=self.entry('Port',self.profile.port)
        self.user=self.entry('Username',self.profile.user)
        self.password=self.entry('Password (blank uses saved keyring credential)',self.profile.password,True)
        self.database=self.entry('Database name / existing SQLite file path',self.profile.database)
        self.tls=self.combo('TLS: prefer permits unencrypted fallback; verify-full validates identity',['disable','prefer','require','verify-full'],self.profile.sslmode)
        self.readonly=self.check('Read-only connection (database-enforced)',self.profile.read_only)
        self.timeout=self.entry('Statement timeout in seconds',self.profile.timeout)
        self.remember=self.check('Store password in desktop Secret Service',self.profile.remember)
        self.note('No passwords are written to configuration. SQLite opens existing files only. Connections are never opened automatically.')
        saved.connect('notify::selected',self._load)
        self.submit('Test',lambda:self.do('test'))
        self.submit('Save',lambda:self.do('save'))
        self.submit('Connect',lambda:self.do('connect'))
        forget=button('Remove saved profile and credential',self.forget)
        self.add(forget)

    def _load(self,drop,*_):
        index=drop.get_selected()
        p=self.saved[index-1] if index else Profile()
        self.profile=p
        for field in ('name','group','host','port','user','database','timeout'):
            getattr(self,field).set_text(str(getattr(p,field)))
        self.password.set_text('')
        for field,options,value in [('engine',['postgres','sqlite'],p.engine),('environment',['development','staging','production'],p.environment),('tls',['disable','prefer','require','verify-full'],p.sslmode)]:
            getattr(self,field).set_selected(options.index(value))
        self.readonly.set_active(p.read_only)
        self.remember.set_active(p.remember)

    def value(self):
        p=replace(self.profile,name=self.name.get_text(),group=self.group.get_text(),engine=combo_text(self.engine),environment=combo_text(self.environment),host=self.host.get_text(),port=int(self.port.get_text()),user=self.user.get_text(),password=self.password.get_text(),database=self.database.get_text(),sslmode=combo_text(self.tls),read_only=self.readonly.get_active(),timeout=int(self.timeout.get_text()),remember=self.remember.get_active())
        p.validate()
        return p

    def do(self,action):
        self.callback(self,self.value(),action)

    def forget(self):
        if self.profile.id not in {p.id for p in self.saved}:
            return
        confirm(self,'Remove connection?',f'Remove {self.profile.name} and its stored credential?','Remove',lambda:self.callback(self,self.value(),'delete'))

class CellDialog(Form):
    def __init__(self,parent,column,value,done):
        super().__init__(parent,'Edit '+column.name)
        self.column=column
        from .widgets import value_text
        self.value=self.entry(f'Value ({column.type})',value_text(value) if value is not None else '')
        self.null=self.check('SQL NULL',value is None)
        self.submit('Stage change',lambda:self.save(done))

    def save(self,done):
        value=self.value.get_text()
        kind=self.column.type.lower()
        if self.null.get_active():
            value=None
        elif kind in ('integer','bigint','smallint','int','int4','int8'):
            value=int(value)
        elif kind.startswith(('numeric','decimal')):
            value=Decimal(value)
        elif kind in ('boolean','bool'):
            if value.lower() not in ('true','false','1','0'):
                raise ValueError('Enter true or false')
            value=value.lower() in ('true','1')
        elif kind in ('json','jsonb') or kind.endswith('[]'):
            value=json.loads(value)
        elif kind in ('bytea','blob'):
            value=bytes.fromhex(value)
        done(value)
        self.close()

class SchemaDialog(Form):
    def __init__(self,parent,profile,schemas,columns,table,apply):
        super().__init__(parent,'Manage columns' if table else 'Create table')
        self.profile=profile
        self.table=table
        self.columns=columns
        self.apply=apply
        self.schema=self.combo('Schema',schemas or ['public' if profile.engine=='postgres' else 'main'],table[0] if table else None)
        self.name=self.entry('Table name',table[1] if table else '')
        if table:
            self.name.set_editable(False)
            operations=['add','rename','drop']+(['type'] if profile.engine=='postgres' else [])
            self.action=self.combo('Operation',operations)
            self.column=self.combo('Existing column',[c.name for c in columns])
            self.new_name=self.entry('New column name')
            self.type=self.combo('Data type',list(TYPES))
        else:
            self.column_box=Gtk.Box(orientation=Gtk.Orientation.VERTICAL,spacing=8)
            self.fields=[]
            self.add(self.column_box)
            self.add_column('id','bigint',True)
            self.add(button('Add column',lambda:self.add_column('','text',False)))
        self.note('The generated SQL is shown for review before execution. Schema changes can lock tables and may permanently change data.')
        self.submit('Review SQL',self.review)

    def add_column(self,name,type,primary):
        if len(self.fields)>=100:
            raise ValueError('Maximum 100 columns')
        box=Gtk.Box(spacing=6)
        entry=Gtk.Entry(text=name,placeholder_text='Column name',hexpand=True)
        drop=Gtk.DropDown.new_from_strings(TYPES)
        drop.set_selected(TYPES.index(type))
        pk=Gtk.CheckButton(label='Primary key',active=primary)
        null=Gtk.CheckButton(label='Nullable',active=not primary)
        for w in (entry,drop,pk,null):
            box.append(w)
        self.column_box.append(box)
        self.fields.append((entry,drop,pk,null))

    def review(self):
        schema=combo_text(self.schema)
        name=self.name.get_text()
        if self.table:
            action=combo_text(self.action)
            column=self.new_name.get_text() if action=='add' else combo_text(self.column)
            text=ddl(schema,name,action,column=column,name=self.new_name.get_text(),type=combo_text(self.type))
        else:
            columns=[dict(name=e.get_text(),type=combo_text(t),primary=p.get_active(),nullable=n.get_active()) for e,t,p,n in self.fields]
            text=ddl(schema,name,'create',columns=columns)
        confirm(self,'Apply schema change?',text,'Execute',lambda:self.apply(self,text),self.profile.database if self.profile.environment=='production' else None)
