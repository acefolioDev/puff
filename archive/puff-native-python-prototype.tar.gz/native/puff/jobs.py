"""One worker per workspace, at most one queued job; no idle polling."""
import queue
import threading
from .security import redact

class Session:
    def __init__(self, profile, dispatch):
        self.profile=profile
        self.dispatch=dispatch
        self.driver=None
        self.jobs=queue.Queue(maxsize=1)
        self.busy=False
        self.closed=False
        self.cancel_pending=False
        self.cancel_event=threading.Event()
        self.thread=threading.Thread(target=self._run, name='puff-database',daemon=True)
        self.thread.start()

    def submit(self, work, done):
        if self.closed or self.busy:
            return False
        self.busy=True
        self.cancel_event.clear()
        self.jobs.put_nowait((work,done))
        return True

    def _run(self):
        while True:
            job=self.jobs.get()
            if job is None:
                break
            work,done=job
            try:
                result=work(self)
                error=None
            except Exception as exc:
                result=None
                code=getattr(exc,'sqlstate',None)
                error=redact(str(exc),self.profile.password)
                if code:
                    error+=f'\nSQLSTATE {code}'
                diag=getattr(exc,'diag',None)
                if diag and diag.statement_position:
                    error+=f'\nPosition {diag.statement_position}'
            if self.closed:
                break
            def deliver(result=result,error=error,done=done):
                self.busy=False
                if not self.closed:
                    done(result,error)
                return False
            self.dispatch(deliver)
        if self.driver:
            self.driver.close()
            self.driver=None
        self.profile.password=''

    def cancel(self):
        self.cancel_event.set()
        if self.cancel_pending or not self.driver:
            return
        self.cancel_pending=True
        def cancel():
            try:
                self.driver.cancel()
            except Exception:
                pass  # Original task reports its database error; never log credentials.
            finally:
                self.cancel_pending=False
        threading.Thread(target=cancel,name='puff-cancel',daemon=True).start()

    def close(self):
        if self.closed:
            return
        self.closed=True
        self.cancel()
        try:
            self.jobs.put_nowait(None)
        except queue.Full:
            pass  # Running job sees closed before delivering and exits itself.
