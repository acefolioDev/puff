"""Native virtualized result presentation; contains no database calls."""
import gi
gi.require_version('Gtk','4.0')
gi.require_version('Adw','1')
from gi.repository import Gtk, GObject, Gio, GLib, Pango
from .export import json_value
import json


def value_text(value):
    if value is None:
        return 'NULL'
    if isinstance(value,(dict,list)):
        return json.dumps(value,ensure_ascii=False,default=json_value)
    if isinstance(value,(bytes,memoryview)):
        return bytes(value).hex()
    return str(value)


def button(label,callback,css=None):
    widget=Gtk.Button(label=label)
    if css:
        widget.add_css_class(css)
    widget.connect('clicked',lambda *_:callback())
    return widget


def padded(box,padding=12):
    box.set_margin_top(padding)
    box.set_margin_bottom(padding)
    box.set_margin_start(padding)
    box.set_margin_end(padding)
    return box


class Row(GObject.Object):
    def __init__(self,index,values):
        super().__init__()
        self.index=index
        self.values=values


class ResultView(Gtk.Box):
    def __init__(self,edit_callback):
        super().__init__(orientation=Gtk.Orientation.VERTICAL,spacing=0)
        self.edit_callback=edit_callback
        self.names=[]
        self.rows=[]
        self.edits={}
        self.columns=[]
        self.filter_source=0
        self.controls=padded(Gtk.Box(spacing=6),6)
        self.search=Gtk.SearchEntry(placeholder_text='Filter current page',hexpand=True)
        self.search.connect('search-changed',self._filter_changed)
        self.controls.append(self.search)
        self.controls.append(button('Copy rows',self.copy))
        self.append(self.controls)
        self.store=Gio.ListStore.new(Row)
        self.filter=Gtk.CustomFilter.new(lambda row: self.search.get_text().casefold() in ' '.join(value_text(v) for v in row.values).casefold())
        self.filtered=Gtk.FilterListModel.new(self.store,self.filter)
        self.sorted=Gtk.SortListModel.new(self.filtered,None)
        self.selection=Gtk.MultiSelection.new(self.sorted)
        self.view=Gtk.ColumnView.new(self.selection)
        self.view.set_show_column_separators(True)
        self.view.set_show_row_separators(True)
        self.sorted.set_sorter(self.view.get_sorter())
        self.scroll=Gtk.ScrolledWindow(vexpand=True,hexpand=True)
        self.scroll.set_child(self.view)
        self.append(self.scroll)

    def _filter_changed(self,*_):
        if self.filter_source:
            GLib.source_remove(self.filter_source)
        def apply():
            self.filter_source=0
            self.filter.changed(Gtk.FilterChange.DIFFERENT)
            return False
        self.filter_source=GLib.timeout_add(150,apply)

    def selected(self):
        return [self.sorted.get_item(i) for i in range(self.sorted.get_n_items()) if self.selection.is_selected(i)]

    def copy(self):
        rows=self.selected()
        if not rows:
            return
        text='\t'.join(self.names)+'\n'+'\n'.join('\t'.join(value_text(v) for v in row.values) for row in rows)
        self.get_clipboard().set(text)

    def set_page(self,names,rows,columns=()):
        self.clear()
        self.names=list(names)
        self.rows=list(rows)
        self.columns=list(columns)
        for index,name in enumerate(names[:100]):
            factory=Gtk.SignalListItemFactory()
            factory.connect('setup',self._setup,index)
            factory.connect('bind',self._bind,index)
            column=Gtk.ColumnViewColumn.new(name,factory)
            column.set_resizable(True)
            column.set_fixed_width(180)
            def compare(a,b,*_,index=index):
                x,y=value_text(a.values[index]),value_text(b.values[index])
                return (x>y)-(x<y)
            column.set_sorter(Gtk.CustomSorter.new(compare))
            self.view.append_column(column)
        self.store.splice(0,0,[Row(i,row) for i,row in enumerate(rows)])

    def _setup(self,factory,item,index):
        label=Gtk.Label(xalign=0,ellipsize=Pango.EllipsizeMode.END)
        label.set_margin_start(8)
        label.set_margin_end(8)
        label.set_margin_top(7)
        label.set_margin_bottom(7)
        gesture=Gtk.GestureClick.new()
        gesture.connect('released',lambda _,n,x,y:self.edit_callback(item.get_item(),index) if n==2 and item.get_item() else None)
        label.add_controller(gesture)
        item.set_child(label)

    def _bind(self,factory,item,index):
        row=item.get_item()
        value=self.edits.get(row.index,{}).get(self.names[index],row.values[index])
        label=item.get_child()
        label.set_text(value_text(value)[:1000])
        label.set_tooltip_text(value_text(value)[:4000])
        for css in ('accent','dim-label'):
            label.remove_css_class(css)
        if self.names[index] in self.edits.get(row.index,{}):
            label.add_css_class('accent')
        elif value is None:
            label.add_css_class('dim-label')

    def stage(self,row,index,value):
        self.edits.setdefault(row.index,{})[self.names[index]]=value
        # Rebind this row through the underlying model without rebuilding all cells.
        self.store.splice(row.index,1,[row])

    def clear(self):
        self.store.remove_all()
        columns=self.view.get_columns()
        while columns.get_n_items():
            self.view.remove_column(columns.get_item(0))
        self.rows=[]
        self.names=[]
        self.columns=[]
        self.edits.clear()

    def dispose_results(self):
        if self.filter_source:
            GLib.source_remove(self.filter_source)
            self.filter_source=0
        self.clear()
