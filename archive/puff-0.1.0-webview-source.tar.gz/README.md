# Puff

A small native PostgreSQL workspace built with Bun, postgres.js, Preact, Tailwind CSS, and webview-bun. Dark by default, with no Electron or bundled browser engine.

## Get started on Fedora

```sh
sudo dnf install gtk4 webkitgtk6.0
bun install --frozen-lockfile
bun run dev
```

Bun 1.4.3 was used for validation. To initialize an empty project manually, the equivalent dependency commands are:

```sh
bun init -y
bun add preact postgres webview-bun@2.4.0
bun add -d typescript @types/bun tailwindcss @tailwindcss/cli
```

This repository already contains the manifest and lockfile; use `bun install` here. No native compilation toolchain is needed for the published webview-bun Linux library. Building that library from source requires `gtk4-devel webkitgtk6.0-devel cmake ninja-build clang`.

## Build and install

```sh
bun run check
bun test
bun run build
./dist/puff
sudo dnf install rpm-build desktop-file-utils
bun run rpm
sudo dnf install ./dist/puff-0.1.0-2*.rpm
```

The build uses Bun's `compile` API (equivalent to `bun build --compile`), embedding frontend JS, compiled Tailwind CSS, the backend worker, and the architecture-specific webview shared library. The output is one `dist/puff` executable. **GTK4, WebKitGTK 6.0 and glibc remain system dependencies**; this is not a statically linked Linux image. Build on the oldest Fedora release you plan to support and test each target. Build natively on x86_64 or aarch64; the script embeds the host architecture's native library. The binary includes the Bun runtime, so its disk size is substantially greater than the frontend bundle.

`package-rpm.sh` uses standard `rpmbuild`, stages files in a temporary directory, disables stripping to preserve Bun's embedded assets, declares Fedora runtime dependencies, and places the RPM in `dist/`. It installs:

- `/usr/bin/puff`
- `/usr/share/applications/puff.desktop`
- `/usr/share/icons/hicolor/scalable/apps/puff.svg`

Fedora's desktop and icon file triggers handle indexing. Search for **Puff** in GNOME after installation. The pipeline packages files without installing anything itself.

## Workspace layout

```text
src/
  shared/types.ts               Shared connection, table, column and row shapes
  backend/
    database.ts                 Connection lifecycle, introspection, CRUD, DDL, raw SQL
    sql.ts                      Identifier quoting, type allowlist, pagination bounds
    profiles.ts                 Private, atomic local connection-profile persistence
    server.ts                   Authenticated loopback API and embedded asset serving
    assets.generated.ts         Generated frontend assets (ignored by Git)
  desktop/
    main.ts                     Native GTK window and worker lifecycle
    server.worker.ts            Backend worker entrypoint
  ui/
    App.tsx                     Workspace and connection state
    api.ts                      API client and error formatting
    components/
      Sidebar.tsx               Schema/table explorer
      ConnectionManager.tsx     Connection form and saved profiles
      DataGrid.tsx              Inline edits, staged deletion, inserts, paging
      SchemaEditor.tsx          Manual table and column operations
      QueryEditor.tsx           SQL editor and results
    styles.css                  Tailwind entrypoint and dark application styling
  types/webview-bun.d.ts        Public API subset isolating upstream FFI type mismatch
scripts/
  build.ts                      Frontend assets and standalone native compile
  package-rpm.sh                Fedora RPM pipeline
  test-postgres.sh              Isolated disposable PostgreSQL integration test
packaging/
  puff.desktop
  puff.svg
tests/                          SQL boundaries, database operations and HTTP access
```

## Using Puff

1. Connect using host, port, user, password, database and TLS settings. Profiles are stored at `$XDG_CONFIG_HOME/puff/connections.json`, falling back to `~/.config/puff/`. The directory is mode 0700 and the file is 0600. Passwords are never persisted; enter them when reconnecting. TLS verifies server certificates using the system trust store.
2. Choose a schema/table in the explorer, including empty schemas. Use **＋** to create a table, add columns, and select a composite or single primary key. **Manage columns** supports add, rename, type conversion and drop. Type conversions use an explicit PostgreSQL cast and fail if existing values cannot be converted. Destructive schema operations require confirmation.
3. Double-click a cell. Enter a JSON value (`"hello"`, `42`, `true`, `null`, an array or object); `NULL` also means SQL NULL. Press Enter or leave the cell to stage it, or Escape to cancel. Changed cells are highlighted. Select row checkboxes to stage deletion. **Save changes** commits the batch in one transaction; any failure rolls back the entire batch. **Discard** clears it. Inserts commit immediately through **Add row**, with unchecked fields omitted so database defaults apply. Identity and generated columns are omitted.
4. Updates/deletes require a full primary key, including all parts of a composite key. Original row values are also compared before mutation to catch concurrent edits. Tables without a primary key allow viewing and inserts. Pagination supports up to 500 rows; primary keys give stable ordering. Without a key, ordering can change between pages.
5. Run custom SQL in **SQL workspace** with Ctrl+Enter (Cmd+Enter also works). Results show elapsed time, row count, column names and PostgreSQL error details. SQL executes with your database user's permissions. Use one statement per execution; prefer LIMIT for large results.

To create another database, connect to the existing `postgres` database, then click **＋ Create database** in the toolbar. Enter its name; after creation Puff opens prefilled connection settings for it. Your role must have `CREATEDB` or superuser privileges. Duplicate names and permission errors appear in the dialog.

## Backend API

The backend runs in a dedicated Bun worker because `webview.run()` occupies the main thread. A random loopback port serves the local frontend. API calls require POST, the exact origin/Host, and an ephemeral token sent in `X-Puff-Token`; CORS is not enabled. A restrictive CSP blocks external scripts and framing. The database client and passwords stay in the backend.

All operations go to `/api` as `{ "action": "...", "payload": {...} }`:

| Action | Payload | Result |
| --- | --- | --- |
| `profiles` | `{}` | saved profiles without passwords |
| `saveProfile` | profile | save connection settings |
| `connect` | profile with optional password | test then switch connection |
| `createDatabase` | `{name}` | create a database on the connected server |
| `explorer` | `{}` | `{schemas, tables}` |
| `page` | `{schema, table, limit, offset}` | `{columns, keys, rows}` |
| `mutate` | `{schema, table, changes}` | atomic insert/update/delete batch |
| `alter` | `{schema, table, action, ...}` | table creation or column DDL |
| `query` | `{text}` | `{rows, columns, count, ms}` |

A mutation is `{kind:'insert', values}`, `{kind:'update', original, values}`, or `{kind:'delete', original}`. Alter actions are `create` (columns with name/type/primary/nullable), `add` (column/type), `rename` (column/name), `type` (column/type), and `drop` (column). User values use bound parameters; identifiers are quoted; DDL types use an allowlist. PostgreSQL introspection types are used to cast original row comparisons. The pool has one connection; overlapping requests fail clearly. Default statement timeout is 30 seconds, lock timeout 5 seconds; raw SQL can change session settings.

## Validation and scaffold limits

```sh
bun run check
bun test                                      # unit tests; integration tests skip
sudo dnf install postgresql-server             # if initdb/pg_ctl are unavailable
bash scripts/test-postgres.sh                  # disposable local cluster, no existing DB used
bun scripts/build.ts --dev
PUFF_TEST_HTTP=1 bun test tests/server.test.ts  # requires loopback socket access
```

Integration tests cover composite keys, original-value conflict detection, atomic rollback, insertion, deletion, and column operations. The local cluster uses a private temporary Unix socket and removes itself afterward.

This is an executable scaffold, not an exhaustive database administration product. The editor is a small native textarea without syntax highlighting. Advanced PostgreSQL types (especially binary, custom types, infinite timestamps and very high precision numeric values) need dedicated codecs before reliable grid round trips; use SQL for those. JavaScript number precision applies to numeric types other than bigint, which is serialized as a string. Array and custom-type editing needs further integration coverage. Queries currently materialize all returned rows and do not offer cancellation or streaming. No SSH tunnel, saved passwords/keyring, profile deletion, schema creation, multi-tab connections, undo history, or arbitrary constraint/index editor is included. Schema changes and inserts commit immediately; grid updates and deletes use explicit Save.

Upstream references: [webview-bun](https://github.com/tr1ckydev/webview-bun), [Bun standalone executables](https://bun.sh/docs/bundler/executables), [postgres.js](https://github.com/porsager/postgres).
