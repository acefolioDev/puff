#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
command -v rpmbuild >/dev/null || { echo 'Install build tools: sudo dnf install rpm-build desktop-file-utils'; exit 1; }
[[ -x dist/puff ]] || { echo 'Run bun run build first'; exit 1; }
command -v desktop-file-validate >/dev/null && desktop-file-validate packaging/puff.desktop
project_root="$PWD"
rpm_root="$(mktemp -d)"
trap 'rm -rf "$rpm_root"' EXIT
mkdir -p "$rpm_root"/{BUILD,BUILDROOT,RPMS,SOURCES,SPECS,SRPMS}
cp dist/puff packaging/puff.desktop packaging/puff.svg LICENSE "$rpm_root/SOURCES/"
cat > "$rpm_root/SPECS/puff.spec" <<'SPEC'
Name: puff
Version: 0.1.0
Release: 2%{?dist}
Summary: Lightweight native PostgreSQL database client
License: MIT
Source0: puff
Source1: puff.desktop
Source2: puff.svg
Source3: LICENSE
Requires: gtk4
Requires: webkitgtk6.0
Requires: glibc
AutoReqProv: yes
# Bun executables contain appended assets; stripping destroys these assets.
%global __strip /bin/true
%global debug_package %{nil}
%global __brp_strip /bin/true
%global __brp_strip_comment_note /bin/true
%description
Puff is a native Bun and Preact PostgreSQL client with inline editing,
schema management, and a SQL workspace using system WebKitGTK.
%prep
%build
%install
install -Dm755 %{SOURCE0} %{buildroot}/usr/bin/puff
install -Dm644 %{SOURCE1} %{buildroot}/usr/share/applications/puff.desktop
install -Dm644 %{SOURCE2} %{buildroot}/usr/share/icons/hicolor/scalable/apps/puff.svg
install -Dm644 %{SOURCE3} %{buildroot}/usr/share/licenses/puff/LICENSE
%files
%license /usr/share/licenses/puff/LICENSE
/usr/bin/puff
/usr/share/applications/puff.desktop
/usr/share/icons/hicolor/scalable/apps/puff.svg
%changelog
* Sun Oct 18 2026 Puff contributors - 0.1.0-2
- Add manual database creation and prefilled connection settings
* Sun Oct 18 2026 Puff contributors - 0.1.0-1
- Initial scaffold
SPEC
rpmbuild --define "_topdir $rpm_root" --define "_tmppath $rpm_root" -bb "$rpm_root/SPECS/puff.spec"
find "$rpm_root/RPMS" -name '*.rpm' -exec cp {} "$project_root/dist/" \;
echo 'RPM written to dist/'
