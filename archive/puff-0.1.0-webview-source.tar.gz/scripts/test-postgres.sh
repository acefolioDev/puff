#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
cluster_dir="$(mktemp -d /tmp/puff-pg.XXXXXX)"
trap 'pg_ctl -D "$cluster_dir/data" -m immediate stop >/dev/null 2>&1 || true; rm -rf "$cluster_dir"' EXIT
initdb -D "$cluster_dir/data" -A trust --no-locale >/dev/null
pg_ctl -D "$cluster_dir/data" -l "$cluster_dir/log" -o "-k $cluster_dir -p 55439 -h ''" -w start >/dev/null
PUFF_TEST_PG="$cluster_dir" bun test
