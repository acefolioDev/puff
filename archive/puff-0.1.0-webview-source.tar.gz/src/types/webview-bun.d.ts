// Public API subset used by Puff. Keeps upstream Bun FFI source typing isolated.
declare module "webview-bun" {
  export enum SizeHint {
    NONE = 0,
    MIN = 1,
    MAX = 2,
    FIXED = 3,
  }
  export class Webview {
    constructor(
      debug?: boolean,
      size?: { width: number; height: number; hint: SizeHint },
    );
    title: string;
    navigate(url: string): void;
    run(): void;
  }
}
