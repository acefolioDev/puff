import { useState } from "preact/hooks";
import { api } from "../api";
import { TYPES } from "../../backend/sql";
import type { Column, Table } from "../../shared/types";
const initial = () => ({
  name: "id",
  type: "bigint",
  primary: true,
  nullable: false,
});
export function SchemaEditor({
  table,
  columns,
  onClose,
  onDone,
}: {
  table?: Table;
  columns: Column[];
  onClose: () => void;
  onDone: () => void;
}) {
  const [schema, setSchema] = useState(table?.schema ?? "public");
  const [name, setName] = useState(table?.name ?? "");
  const [action, setAction] = useState(table ? "add" : "create");
  const [column, setColumn] = useState(columns[0]?.name ?? "");
  const [newName, setNewName] = useState("");
  const [type, setType] = useState("text");
  const [cols, setCols] = useState([initial()]);
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const [confirm, setConfirm] = useState(false);
  return (
    <div class="overlay">
      <form
        class="modal wide"
        onSubmit={async (e) => {
          e.preventDefault();
          setBusy(true);
          setError("");
          try {
            await api("alter", {
              schema,
              table: name,
              action,
              column: action === "add" ? newName : column,
              name: newName,
              type,
              columns: cols,
            });
            onDone();
          } catch (e) {
            setError((e as Error).message);
          } finally {
            setBusy(false);
          }
        }}
      >
        <header>
          <h2>{table ? "Manage columns" : "Create a table"}</h2>
          <button type="button" onClick={onClose}>
            ×
          </button>
        </header>
        {!table ? (
          <>
            <div class="form-grid">
              <label>
                Schema
                <input
                  required
                  value={schema}
                  onInput={(e) => setSchema(e.currentTarget.value)}
                />
              </label>
              <label>
                Table name
                <input
                  required
                  value={name}
                  onInput={(e) => setName(e.currentTarget.value)}
                />
              </label>
            </div>
            {cols.map((c, i) => (
              <div class="column-row">
                <input
                  required
                  aria-label="Column name"
                  value={c.name}
                  onInput={(e) =>
                    setCols(
                      cols.map((v, j) =>
                        j === i ? { ...v, name: e.currentTarget.value } : v,
                      ),
                    )
                  }
                />
                <select
                  value={c.type}
                  onChange={(e) =>
                    setCols(
                      cols.map((v, j) =>
                        j === i ? { ...v, type: e.currentTarget.value } : v,
                      ),
                    )
                  }
                >
                  {TYPES.map((t) => (
                    <option>{t}</option>
                  ))}
                </select>
                <label class="check">
                  <input
                    type="checkbox"
                    checked={c.primary}
                    onChange={(e) =>
                      setCols(
                        cols.map((v, j) =>
                          j === i
                            ? { ...v, primary: e.currentTarget.checked }
                            : v,
                        ),
                      )
                    }
                  />
                  PK
                </label>
                <label class="check">
                  <input
                    type="checkbox"
                    checked={c.nullable}
                    onChange={(e) =>
                      setCols(
                        cols.map((v, j) =>
                          j === i
                            ? { ...v, nullable: e.currentTarget.checked }
                            : v,
                        ),
                      )
                    }
                  />
                  Nullable
                </label>
                <button
                  type="button"
                  disabled={cols.length === 1}
                  onClick={() => setCols(cols.filter((_, j) => j !== i))}
                >
                  ×
                </button>
              </div>
            ))}
            <button
              type="button"
              onClick={() =>
                setCols([
                  ...cols,
                  { name: "", type: "text", primary: false, nullable: true },
                ])
              }
            >
              ＋ Add column
            </button>
          </>
        ) : (
          <>
            <label>
              Operation
              <select
                value={action}
                onChange={(e) => {
                  setAction(e.currentTarget.value);
                  setConfirm(false);
                }}
              >
                <option value="add">Add column</option>
                <option value="rename">Rename column</option>
                <option value="type">Change data type</option>
                <option value="drop">Drop column</option>
              </select>
            </label>
            {action !== "add" && (
              <label>
                Column
                <select
                  value={column}
                  onChange={(e) => setColumn(e.currentTarget.value)}
                >
                  {columns.map((c) => (
                    <option>{c.name}</option>
                  ))}
                </select>
              </label>
            )}
            {["add", "rename"].includes(action) && (
              <label>
                New name
                <input
                  required
                  value={newName}
                  onInput={(e) => setNewName(e.currentTarget.value)}
                />
              </label>
            )}
            {["add", "type"].includes(action) && (
              <label>
                Type
                <select
                  value={type}
                  onChange={(e) => setType(e.currentTarget.value)}
                >
                  {TYPES.map((t) => (
                    <option>{t}</option>
                  ))}
                </select>
              </label>
            )}
            {["drop", "type"].includes(action) && (
              <label class="check">
                <input
                  type="checkbox"
                  required
                  checked={confirm}
                  onChange={(e) => setConfirm(e.currentTarget.checked)}
                />
                I understand this operation can permanently change or remove
                data.
              </label>
            )}
          </>
        )}
        {error && <pre class="error">{error}</pre>}
        <footer>
          <button type="button" onClick={onClose}>
            Cancel
          </button>
          <button class="primary" disabled={busy}>
            {busy ? "Applying…" : "Apply schema change"}
          </button>
        </footer>
      </form>
    </div>
  );
}
