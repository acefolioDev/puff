import { useState } from "preact/hooks";
import { api } from "../api";
export function CreateDatabase({
  onClose,
  onCreated,
}: {
  onClose: () => void;
  onCreated: (name: string) => void;
}) {
  const [name, setName] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  return (
    <div class="overlay">
      <form
        class="modal"
        onSubmit={async (e) => {
          e.preventDefault();
          setBusy(true);
          setError("");
          try {
            await api("createDatabase", { name });
            onCreated(name);
          } catch (e) {
            setError((e as Error).message);
          } finally {
            setBusy(false);
          }
        }}
      >
        <header>
          <h2>Create database</h2>
          <button type="button" disabled={busy} onClick={onClose}>
            ×
          </button>
        </header>
        <p class="muted">
          Create a database on the connected PostgreSQL server. Your role needs
          CREATEDB or superuser privileges. After creation, review the
          connection settings to open it.
        </p>
        <label>
          Database name
          <input
            required
            autoFocus
            value={name}
            onInput={(e) => setName(e.currentTarget.value)}
            disabled={busy}
          />
        </label>
        {error && (
          <pre class="error" role="alert">
            {error}
          </pre>
        )}
        <footer>
          <button type="button" disabled={busy} onClick={onClose}>
            Cancel
          </button>
          <button class="primary" disabled={busy}>
            {busy ? "Creating…" : "Create database"}
          </button>
        </footer>
      </form>
    </div>
  );
}
