import type { Table } from "../../shared/types";
export function Sidebar({
  tables,
  schemas,
  active,
  onSelect,
  onConnect,
  onCreate,
  connected,
}: {
  tables: Table[];
  schemas: string[];
  active?: Table;
  onSelect: (t: Table) => void;
  onConnect: () => void;
  onCreate: () => void;
  connected: boolean;
}) {
  return (
    <aside>
      <div class="brand">
        <span class="cloud">☁</span> puff <small>POSTGRESQL</small>
      </div>
      <button class="connection" onClick={onConnect}>
        <span class={connected ? "dot live" : "dot"} />{" "}
        {connected ? "Manage connection" : "Connect database"} <span>＋</span>
      </button>
      <div class="section-label">
        EXPLORER{" "}
        <button disabled={!connected} title="Create table" onClick={onCreate}>
          ＋
        </button>
      </div>
      {schemas.map((s) => (
        <details open key={s}>
          <summary>▾ {s}</summary>
          {tables
            .filter((t) => t.schema === s)
            .map((t) => (
              <button
                key={t.name}
                class={
                  "table-link " +
                  (active?.schema === s && active.name === t.name
                    ? "active"
                    : "")
                }
                onClick={() => onSelect(t)}
              >
                ▦ <span>{t.name}</span>
              </button>
            ))}
        </details>
      ))}
      {!tables.length && (
        <p class="muted p-4">
          {connected
            ? "No user tables yet. Create your first table."
            : "Your databases, a little lighter."}
        </p>
      )}
      <div class="sidebar-footer">● Local desktop workspace</div>
    </aside>
  );
}
