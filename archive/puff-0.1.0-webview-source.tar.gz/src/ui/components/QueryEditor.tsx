import { useState } from "preact/hooks";
import { api, display } from "../api";
export function QueryEditor() {
  const [sql, setSql] = useState(
    "SELECT current_database(), current_user, version();",
  );
  const [result, setResult] = useState<any>();
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  async function run() {
    if (busy) return;
    setBusy(true);
    setError("");
    setResult(undefined);
    try {
      setResult(await api("query", { text: sql }));
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setBusy(false);
    }
  }
  return (
    <div class="query">
      <div class="toolbar">
        <span class="muted">
          SQL workspace · queries run directly against your database
        </span>
        <div class="spacer" />
        <button class="primary" disabled={busy} onClick={run}>
          {busy ? "Running…" : "Run query"} <kbd>Ctrl ↵</kbd>
        </button>
      </div>
      <textarea
        aria-label="SQL editor"
        spellcheck={false}
        value={sql}
        onInput={(e) => setSql(e.currentTarget.value)}
        onKeyDown={(e) => {
          if ((e.ctrlKey || e.metaKey) && e.key === "Enter") {
            e.preventDefault();
            void run();
          }
        }}
      />
      {error && (
        <pre role="alert" class="error">
          {error}
        </pre>
      )}
      {result && (
        <>
          <div class="toolbar">
            <span class="success">✓ Query completed</span>
            <span>
              {result.ms.toFixed(1)} ms · {result.count ?? result.rows.length}{" "}
              rows affected
            </span>
          </div>
          <div class="grid-scroll">
            <table>
              <thead>
                <tr>
                  {result.columns.map((c: string) => (
                    <th>{c}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {result.rows.map((r: any) => (
                  <tr>
                    {result.columns.map((c: string) => (
                      <td>{display(r[c])}</td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </>
      )}
    </div>
  );
}
