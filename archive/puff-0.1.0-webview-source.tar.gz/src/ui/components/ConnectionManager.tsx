import { useEffect, useState } from "preact/hooks";
import { api } from "../api";
import type { Profile } from "../../shared/types";
export function ConnectionManager({
  onClose,
  onConnected,
  initialProfile,
}: {
  initialProfile?: Profile;
  onClose: () => void;
  onConnected: (p: Profile) => void;
}) {
  const [profiles, setProfiles] = useState<Profile[]>([]);
  const [p, setP] = useState<Profile>(
    initialProfile ?? {
      id: crypto.randomUUID(),
      name: "Local PostgreSQL",
      host: "localhost",
      port: 5432,
      user: "postgres",
      password: "",
      database: "postgres",
      ssl: false,
    },
  );
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  useEffect(() => {
    api<Profile[]>("profiles")
      .then(setProfiles)
      .catch((e) => setError(e.message));
  }, []);
  return (
    <div class="overlay">
      <form
        class="modal"
        onSubmit={async (e) => {
          e.preventDefault();
          setBusy(true);
          setError("");
          try {
            await api("connect", p);
            await api("saveProfile", p);
            onConnected(p);
          } catch (e) {
            setError((e as Error).message);
          } finally {
            setBusy(false);
          }
        }}
      >
        <header>
          <h2>Connect to PostgreSQL</h2>
          <button type="button" onClick={onClose}>
            ×
          </button>
        </header>
        <p class="muted">A direct connection to your database.</p>
        <label>
          Saved connections
          <select
            onChange={(e) => {
              const found = profiles.find(
                (p) => p.id === e.currentTarget.value,
              );
              if (found) setP({ ...found, password: "" });
            }}
          >
            <option value="">New connection</option>
            {profiles.map((p) => (
              <option value={p.id}>{p.name}</option>
            ))}
          </select>
        </label>
        <div class="form-grid">
          {(
            ["name", "host", "port", "user", "password", "database"] as const
          ).map((key) => (
            <label>
              {key}
              <input
                required={key !== "password"}
                type={
                  key === "password"
                    ? "password"
                    : key === "port"
                      ? "number"
                      : "text"
                }
                value={p[key] ?? ""}
                onInput={(e) =>
                  setP({
                    ...p,
                    [key]:
                      key === "port"
                        ? Number(e.currentTarget.value)
                        : e.currentTarget.value,
                  })
                }
              />
            </label>
          ))}
        </div>
        <label class="check">
          <input
            type="checkbox"
            checked={p.ssl}
            onChange={(e) => setP({ ...p, ssl: e.currentTarget.checked })}
          />
          Require TLS (certificate verification enabled)
        </label>
        <p class="muted">
          Passwords are kept in memory and never saved to profiles.
        </p>
        {error && <pre class="error">{error}</pre>}
        <footer>
          <button type="button" onClick={onClose}>
            Cancel
          </button>
          <button class="primary" disabled={busy}>
            {busy ? "Connecting…" : "Connect & save profile"}
          </button>
        </footer>
      </form>
    </div>
  );
}
