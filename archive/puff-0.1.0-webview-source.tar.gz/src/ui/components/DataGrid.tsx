import { useEffect, useState } from "preact/hooks";
import type { Page, Row, Table } from "../../shared/types";
import { api, display } from "../api";
export function DataGrid({
  table,
  refresh,
  onStatus,
  onDirty,
}: {
  table: Table;
  refresh: number;
  onStatus: (s: string) => void;
  onDirty: (v: boolean) => void;
}) {
  const [page, setPage] = useState<Page>({ rows: [], columns: [], keys: [] });
  const [offset, setOffset] = useState(0);
  const [limit, setLimit] = useState(100);
  const [edits, setEdits] = useState<Record<number, Row>>({});
  const [deleted, setDeleted] = useState<number[]>([]);
  const [editing, setEditing] = useState<string>();
  const [draft, setDraft] = useState("");
  const [busy, setBusy] = useState(false);
  const [reload, setReload] = useState(0);
  const [add, setAdd] = useState(false);
  const [insert, setInsert] = useState<Row>({});
  const [error, setError] = useState("");
  const dirty = !!Object.keys(edits).length || !!deleted.length;
  useEffect(() => {
    onDirty(dirty);
  }, [dirty]);
  useEffect(() => {
    let alive = true;
    setBusy(true);
    setError("");
    api<Page>("page", { ...table, limit, offset })
      .then((p) => {
        if (alive) {
          setPage(p);
          setEdits({});
          setDeleted([]);
          onStatus(`${p.rows.length} rows loaded`);
        }
      })
      .catch((e) => {
        if (alive) setError(e.message);
      })
      .finally(() => {
        if (alive) setBusy(false);
      });
    return () => {
      alive = false;
    };
  }, [table.schema, table.name, offset, limit, refresh, reload]);
  function commit(i: number, column: string) {
    try {
      const value = draft === "NULL" ? null : JSON.parse(draft);
      setEdits({ ...edits, [i]: { ...edits[i], [column]: value } });
      setEditing(undefined);
      setError("");
    } catch {
      setError(
        'Use a JSON value: "text", 42, true, null, or an object. NULL also sets SQL NULL.',
      );
    }
  }
  async function save() {
    setBusy(true);
    setError("");
    try {
      await api("mutate", {
        ...table,
        changes: [
          ...Object.entries(edits)
            .filter(([i]) => !deleted.includes(Number(i)))
            .map(([i, values]) => ({
              kind: "update",
              original: page.rows[Number(i)],
              values,
            })),
          ...deleted.map((i) => ({ kind: "delete", original: page.rows[i] })),
        ],
      });
      setEdits({});
      setDeleted([]);
      onStatus("Changes committed");
      setReload((v) => v + 1);
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setBusy(false);
    }
  }
  return (
    <>
      <div class="toolbar">
        <span class="muted">
          {page.keys.length
            ? "Double-click a cell to edit"
            : "No primary key · updates and deletes disabled"}
        </span>
        <div class="spacer" />
        <button
          disabled={busy || dirty}
          onClick={() => {
            setInsert({});
            setAdd(true);
          }}
        >
          ＋ Add row
        </button>
        <button
          disabled={busy || !dirty}
          onClick={() => {
            setEdits({});
            setDeleted([]);
          }}
        >
          Discard
        </button>
        <button class="primary" disabled={busy || !dirty} onClick={save}>
          Save changes{dirty ? " •" : ""}
        </button>
      </div>
      {error && (
        <pre role="alert" class="error">
          {error}
        </pre>
      )}
      <div class="grid-scroll">
        <table>
          <thead>
            <tr>
              <th />
              <th>#</th>
              {page.columns.map((c) => (
                <th key={c.name}>
                  {c.primary ? "⚿ " : ""}
                  {c.name}
                  <small>{c.type}</small>
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {page.rows.map((row, i) => (
              <tr key={i} class={deleted.includes(i) ? "deleted" : ""}>
                <td>
                  <input
                    aria-label={`Delete row ${i + 1}`}
                    type="checkbox"
                    disabled={!page.keys.length || busy}
                    checked={deleted.includes(i)}
                    onChange={(e) =>
                      setDeleted(
                        e.currentTarget.checked
                          ? [...deleted, i]
                          : deleted.filter((x) => x !== i),
                      )
                    }
                  />
                </td>
                <td class="muted">{offset + i + 1}</td>
                {page.columns.map((c) => {
                  const changed = edits[i] && c.name in edits[i];
                  const value = changed ? edits[i][c.name] : row[c.name];
                  const id = `${i}:${c.name}`;
                  return (
                    <td
                      key={c.name}
                      class={changed ? "changed" : value === null ? "null" : ""}
                      onDblClick={() => {
                        if (!busy && page.keys.length && !c.generated) {
                          setEditing(id);
                          setDraft(
                            value === null ? "NULL" : JSON.stringify(value),
                          );
                        }
                      }}
                    >
                      {editing === id ? (
                        <input
                          aria-label={`Edit ${c.name}`}
                          autoFocus
                          value={draft}
                          onInput={(e) => setDraft(e.currentTarget.value)}
                          onKeyDown={(e) => {
                            if (e.key === "Enter") commit(i, c.name);
                            if (e.key === "Escape") setEditing(undefined);
                          }}
                          onBlur={() => commit(i, c.name)}
                        />
                      ) : (
                        display(value)
                      )}
                    </td>
                  );
                })}
              </tr>
            ))}
          </tbody>
        </table>
        {!page.rows.length && !busy && (
          <div class="empty">
            <h2>No rows yet</h2>
            <p>Add a row to start building your data.</p>
          </div>
        )}
        {busy && <div class="loading">Working…</div>}
      </div>
      <div class="toolbar bottom">
        <span class="muted">
          {page.rows.length} rows · {Object.keys(edits).length} edited ·{" "}
          {deleted.length} marked for deletion
        </span>
        <div class="spacer" />
        <select
          aria-label="Rows per page"
          disabled={dirty || busy}
          value={limit}
          onChange={(e) => {
            setLimit(Number(e.currentTarget.value));
            setOffset(0);
          }}
        >
          {[50, 100, 250, 500].map((n) => (
            <option value={n}>{n} rows</option>
          ))}
        </select>
        <button
          disabled={dirty || busy || !offset}
          onClick={() => setOffset(Math.max(0, offset - limit))}
        >
          ← Previous
        </button>
        <span>
          {offset + 1}–{offset + page.rows.length}
        </span>
        <button
          disabled={dirty || busy || page.rows.length < limit}
          onClick={() => setOffset(offset + limit)}
        >
          Next →
        </button>
      </div>
      {add && (
        <div class="overlay">
          <form
            class="modal"
            onSubmit={async (e) => {
              e.preventDefault();
              setBusy(true);
              try {
                await api("mutate", {
                  ...table,
                  changes: [{ kind: "insert", values: insert }],
                });
                setAdd(false);
                setReload((v) => v + 1);
                onStatus("Row inserted");
              } catch (e) {
                setError((e as Error).message);
              } finally {
                setBusy(false);
              }
            }}
          >
            <h2>Add row</h2>
            <p class="muted">
              Enable fields to supply values. Unchecked fields use database
              defaults. Enter JSON values.
            </p>
            {page.columns
              .filter((c) => !c.generated)
              .map((c) => (
                <label class="insert-field">
                  <input
                    type="checkbox"
                    checked={c.name in insert}
                    onChange={(e) => {
                      const next = { ...insert };
                      if (e.currentTarget.checked) next[c.name] = null;
                      else delete next[c.name];
                      setInsert(next);
                    }}
                  />
                  {c.name}
                  <input
                    disabled={!(c.name in insert)}
                    placeholder='"text", 42, null'
                    onInput={(e) => {
                      try {
                        setInsert({
                          ...insert,
                          [c.name]: JSON.parse(e.currentTarget.value),
                        });
                        e.currentTarget.setCustomValidity("");
                      } catch {
                        e.currentTarget.setCustomValidity("Enter valid JSON");
                      }
                    }}
                  />
                </label>
              ))}
            {error && <pre class="error">{error}</pre>}
            <footer>
              <button type="button" onClick={() => setAdd(false)}>
                Cancel
              </button>
              <button disabled={busy} class="primary">
                Insert row
              </button>
            </footer>
          </form>
        </div>
      )}
    </>
  );
}
