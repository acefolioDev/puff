export async function api<T = any>(
  action: string,
  payload: unknown = {},
): Promise<T> {
  const response = await fetch("/api", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "X-Puff-Token": document.querySelector<HTMLMetaElement>(
        'meta[name="puff-token"]',
      )!.content,
    },
    body: JSON.stringify({ action, payload }),
  });
  const result = await response.json();
  if (!response.ok)
    throw new Error(
      [
        result.error,
        result.code && `SQLSTATE ${result.code}`,
        result.detail,
        result.hint,
        result.position && `Position ${result.position}`,
      ]
        .filter(Boolean)
        .join("\n"),
    );
  return result;
}
export function display(v: unknown): string {
  return v === null
    ? "NULL"
    : typeof v === "object"
      ? JSON.stringify(v)
      : String(v ?? "");
}
