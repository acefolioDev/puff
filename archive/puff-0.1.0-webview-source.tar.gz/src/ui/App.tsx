import { useState } from "preact/hooks";
import { Sidebar } from "./components/Sidebar";
import { ConnectionManager } from "./components/ConnectionManager";
import { DataGrid } from "./components/DataGrid";
import { QueryEditor } from "./components/QueryEditor";
import { SchemaEditor } from "./components/SchemaEditor";
import { api } from "./api";
import { CreateDatabase } from "./components/CreateDatabase";
import type { Table, Column, Profile } from "../shared/types";
export function App() {
  const [databaseModal, setDatabaseModal] = useState(false);
  const [activeProfile, setActiveProfile] = useState<Profile>();
  const [connectionDraft, setConnectionDraft] = useState<Profile>();
  const [schemas, setSchemas] = useState<string[]>([]);
  const [tables, setTables] = useState<Table[]>([]);
  const [active, setActive] = useState<Table>();
  const [connection, setConnection] = useState(false);
  const [connected, setConnected] = useState(false);
  const [profile, setProfile] = useState("");
  const [tab, setTab] = useState("data");
  const [status, setStatus] = useState("Ready to connect");
  const [schema, setSchema] = useState<"create" | "edit">();
  const [columns, setColumns] = useState<Column[]>([]);
  const [refresh, setRefresh] = useState(0);
  const [dirty, setDirty] = useState(false);
  async function reload() {
    const result = await api("explorer");
    setTables(result.tables);
    setSchemas(result.schemas);
  }
  function mayLeave() {
    return !dirty || confirm("Discard unsaved changes?");
  }
  return (
    <div class="app">
      <Sidebar
        schemas={schemas}
        tables={tables}
        active={active}
        connected={connected}
        onConnect={() => {
          if (mayLeave()) {
            setConnectionDraft(activeProfile);
            setConnection(true);
          }
        }}
        onCreate={() => {
          if (mayLeave()) setSchema("create");
        }}
        onSelect={(t) => {
          if (mayLeave()) {
            setActive(t);
            setDirty(false);
            setRefresh((v) => v + 1);
            setTab("data");
          }
        }}
      />
      <main>
        <header class="main-header">
          <div>
            <span class="muted">Workspace / {profile || "Welcome"}</span>
            <h1>
              {active?.name ?? "A little room for your data"}
              {active && <small>{active.schema}</small>}
            </h1>
          </div>
          <span class="badge">{connected ? "● Connected" : "○ Offline"}</span>
        </header>
        {connected ? (
          <>
            <nav>
              <button
                class={tab === "data" ? "selected" : ""}
                onClick={() => setTab("data")}
              >
                ▦ Table data
              </button>
              <button
                class={tab === "sql" ? "selected" : ""}
                onClick={() => setTab("sql")}
              >
                ⌘ SQL workspace
              </button>
              <div class="spacer" />
              <button onClick={() => setDatabaseModal(true)}>
                ＋ Create database
              </button>
              {active && (
                <button
                  onClick={async () => {
                    if (!mayLeave()) return;
                    try {
                      const p = await api("page", { ...active, limit: 1 });
                      setColumns(p.columns);
                      setSchema("edit");
                    } catch (e) {
                      setStatus((e as Error).message);
                    }
                  }}
                >
                  Manage columns
                </button>
              )}
              <button
                disabled={dirty}
                onClick={() => {
                  reload()
                    .then(() => setRefresh((v) => v + 1))
                    .catch((e) => setStatus(e.message));
                }}
              >
                ↻ Refresh
              </button>
            </nav>
            <div class="content" hidden={tab !== "data"}>
              {active ? (
                <DataGrid
                  key={`${profile}:${active.schema}:${active.name}`}
                  table={active}
                  refresh={refresh}
                  onStatus={setStatus}
                  onDirty={setDirty}
                />
              ) : (
                <div class="empty">
                  <h2>Your workspace is ready</h2>
                  <p>Select a table, create one, or open the SQL workspace.</p>
                </div>
              )}
            </div>
            <div class="content" hidden={tab !== "sql"}>
              <QueryEditor />
            </div>
          </>
        ) : (
          <div class="empty welcome">
            <div class="hero-cloud">☁</div>
            <h2>
              Meet your database.
              <br />
              Minus the weight.
            </h2>
            <p>
              A quiet, native workspace for PostgreSQL.
              <br />
              Explore tables, shape schemas, and make every query count.
            </p>
            <button class="primary" onClick={() => setConnection(true)}>
              ＋ Connect a database
            </button>
          </div>
        )}
        <div class="status" role="status">
          <span class="dot live" />
          {status}
          <div class="spacer" />
          <span>Puff 0.1.0</span>
        </div>
      </main>
      {connection && (
        <ConnectionManager
          initialProfile={connectionDraft}
          onClose={() => setConnection(false)}
          onConnected={(p) => {
            setActiveProfile(p);
            setConnected(true);
            setProfile(p.name);
            setActive(undefined);
            setDirty(false);
            setConnection(false);
            reload().catch((e) => setStatus(e.message));
            setStatus(`Connected to ${p.database}`);
          }}
        />
      )}
      {databaseModal && (
        <CreateDatabase
          onClose={() => setDatabaseModal(false)}
          onCreated={(name) => {
            setDatabaseModal(false);
            setStatus(`Database ${name} created`);
            if (activeProfile && mayLeave()) {
              setConnectionDraft({
                ...activeProfile,
                id: crypto.randomUUID(),
                name,
                database: name,
              });
              setConnection(true);
            }
          }}
        />
      )}
      {schema && (
        <SchemaEditor
          table={schema === "edit" ? active : undefined}
          columns={columns}
          onClose={() => setSchema(undefined)}
          onDone={() => {
            setSchema(undefined);
            setDirty(false);
            setRefresh((v) => v + 1);
            reload().catch((e) => setStatus(e.message));
            setStatus("Schema updated");
          }}
        />
      )}
    </div>
  );
}
