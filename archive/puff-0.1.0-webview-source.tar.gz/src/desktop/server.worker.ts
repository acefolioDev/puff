// Co-located entrypoint preserves worker resolution in Bun standalone executables.
import "../backend/server";
