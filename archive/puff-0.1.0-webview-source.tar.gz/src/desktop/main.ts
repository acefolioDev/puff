import { Webview, SizeHint } from "webview-bun";
const worker = new Worker(new URL("./server.worker.ts", import.meta.url).href);
try {
  const url = await new Promise<string>((resolve, reject) => {
    worker.onmessage = (e) => resolve(e.data.url);
    worker.onerror = reject;
  });
  const window = new Webview(false, {
    width: 1280,
    height: 820,
    hint: SizeHint.NONE,
  });
  window.title = "Puff · PostgreSQL";
  window.navigate(url);
  window.run();
} finally {
  worker.postMessage("close");
  setTimeout(() => worker.terminate(), 1500);
}
