import postgres from "postgres";
import type { Profile, Column, Row } from "../shared/types";
import { ident, qualified, dataType, bounded } from "./sql";
export class Database {
  private sql: ReturnType<typeof postgres> | undefined;
  private busy = false;
  async exclusive<T>(fn: () => Promise<T>): Promise<T> {
    if (this.busy) throw new Error("Another database operation is running");
    this.busy = true;
    try {
      return await fn();
    } finally {
      this.busy = false;
    }
  }
  async connect(p: Profile) {
    if (
      !p.host ||
      !p.user ||
      !p.database ||
      !Number.isInteger(p.port) ||
      p.port < 1 ||
      p.port > 65535
    )
      throw new Error("Invalid connection settings");
    const next = postgres({
      host: p.host,
      port: p.port,
      username: p.user,
      password: p.password ?? "",
      database: p.database,
      ssl: p.ssl ? { rejectUnauthorized: true } : false,
      max: 1,
      connect_timeout: 10,
      idle_timeout: 20,
      prepare: false,
      connection: { statement_timeout: 30000, lock_timeout: 5000 },
      types: { bigint: postgres.BigInt },
    });
    try {
      await next`select 1`;
    } catch (e) {
      await next.end({ timeout: 1 });
      throw e;
    }
    await this.sql?.end({ timeout: 1 });
    this.sql = next;
  }
  private db() {
    if (!this.sql) throw new Error("Connect to a database first");
    return this.sql;
  }
  async close() {
    await this.sql?.end({ timeout: 1 });
    this.sql = undefined;
  }
  async createDatabase(name: string) {
    await this.db().unsafe(`create database ${ident(name)}`);
    return { name };
  }
  async explorer() {
    const tables =
      await this.db()`select n.nspname as schema, c.relname as name from pg_class c join pg_namespace n on n.oid=c.relnamespace where c.relkind in ('r','p') and n.nspname not in ('pg_catalog','information_schema') and n.nspname not like 'pg_toast%' order by 1,2`;
    const schemas =
      await this.db()`select nspname as name from pg_namespace where nspname not in ('pg_catalog','information_schema') and nspname not like 'pg_%' order by 1`;
    return { tables, schemas: schemas.map((s) => s.name as string) };
  }
  async columns(schema: string, table: string): Promise<Column[]> {
    return (await this.db()`select a.attname as name, format_type(a.atttypid,a.atttypmod) as type, not a.attnotnull as nullable, (a.attgenerated <> '' or a.attidentity <> '') as generated, exists(select 1 from pg_index i where i.indrelid=c.oid and i.indisprimary and a.attnum=any(i.indkey)) as primary from pg_attribute a join pg_class c on c.oid=a.attrelid join pg_namespace n on n.oid=c.relnamespace where n.nspname=${schema} and c.relname=${table} and a.attnum>0 and not a.attisdropped order by a.attnum`) as unknown as Column[];
  }
  async page(p: any) {
    const columns = await this.columns(p.schema, p.table);
    const keys = columns.filter((c) => c.primary).map((c) => c.name);
    const limit = bounded(p.limit, 500, 100);
    if (limit === 0) throw new Error("Limit must be positive");
    const offset = bounded(p.offset, 100000000, 0);
    const rows = await this.db().unsafe(
      `select * from ${qualified(p.schema, p.table)}${keys.length ? " order by " + keys.map(ident).join(",") : ""} limit $1 offset $2`,
      [limit, offset],
    );
    return { rows, columns, keys };
  }
  async mutate(p: any) {
    const columns = await this.columns(p.schema, p.table);
    const keys = columns.filter((c) => c.primary).map((c) => c.name);
    const table = qualified(p.schema, p.table);
    if (!Array.isArray(p.changes) || p.changes.length > 500)
      throw new Error("Invalid change batch");
    return this.db().begin(async (tx) => {
      for (const change of p.changes) {
        const values: unknown[] = [];
        const param = (v: unknown) => {
          values.push(v);
          return "$" + values.length;
        };
        let query = "";
        if (change.kind === "insert") {
          const entries = Object.entries(change.values as Row);
          entries.forEach(([k]) => {
            if (!columns.some((c) => c.name === k && !c.generated))
              throw new Error("Invalid writable column");
          });
          query = entries.length
            ? `insert into ${table} (${entries.map(([k]) => ident(k)).join(",")}) values (${entries.map(([, v]) => param(v)).join(",")})`
            : `insert into ${table} default values`;
        } else {
          if (
            !keys.length ||
            !change.original ||
            keys.some(
              (k) =>
                change.original[k] === undefined || change.original[k] === null,
            )
          )
            throw new Error("A complete primary key is required");
          if (change.kind === "update") {
            const entries = Object.entries(change.values as Row);
            if (!entries.length) continue;
            entries.forEach(([k]) => {
              if (!columns.some((c) => c.name === k && !c.generated))
                throw new Error("Invalid writable column");
            });
            query = `update ${table} set ${entries.map(([k, v]) => `${ident(k)}=${param(v)}`).join(",")}`;
          } else if (change.kind === "delete") query = `delete from ${table}`;
          else throw new Error("Unknown mutation");
          // Compare the entire original row to avoid overwriting concurrent changes.
          const predicates = columns.map((c) => {
            if (!(c.name in change.original))
              throw new Error("Original row is incomplete");
            const raw = change.original[c.name];
            const value =
              raw !== null && /^(json|jsonb)$/.test(c.type)
                ? JSON.stringify(raw)
                : raw;
            return `to_jsonb(${ident(c.name)}) is not distinct from to_jsonb(${param(value)}::text::${c.type})`;
          });
          query += " where " + predicates.join(" and ");
        }
        const result = await tx.unsafe(query, values as any[]);
        if (result.count !== 1)
          throw new Error("Row changed or disappeared. Reload before saving.");
      }
      return { saved: p.changes.length };
    });
  }
  async alter(p: any) {
    const table = qualified(p.schema, p.table);
    let query = "";
    switch (p.action) {
      case "create": {
        if (!Array.isArray(p.columns) || !p.columns.length)
          throw new Error("At least one column is required");
        const primary = p.columns
          .filter((c: any) => c.primary)
          .map((c: any) => ident(c.name));
        query = `create table ${table} (${p.columns.map((c: any) => `${ident(c.name)} ${dataType(c.type)}${c.nullable === false ? " not null" : ""}`).join(",")}${primary.length ? ", primary key (" + primary.join(",") + ")" : ""})`;
        break;
      }
      case "add":
        query = `alter table ${table} add column ${ident(p.column)} ${dataType(p.type)}`;
        break;
      case "rename":
        query = `alter table ${table} rename column ${ident(p.column)} to ${ident(p.name)}`;
        break;
      case "type":
        query = `alter table ${table} alter column ${ident(p.column)} type ${dataType(p.type)} using ${ident(p.column)}::${dataType(p.type)}`;
        break;
      case "drop":
        query = `alter table ${table} drop column ${ident(p.column)}`;
        break;
      default:
        throw new Error("Unknown schema operation");
    }
    await this.db().unsafe(query);
    return { ok: true };
  }
  async query(text: string) {
    if (typeof text !== "string" || !text.trim() || text.length > 1000000)
      throw new Error("Enter a SQL query (maximum 1 MB)");
    const start = performance.now();
    const result = await this.db().unsafe(text);
    return {
      rows: result,
      columns: result.columns?.map((c) => c.name) ?? [],
      count: result.count,
      ms: performance.now() - start,
    };
  }
}
