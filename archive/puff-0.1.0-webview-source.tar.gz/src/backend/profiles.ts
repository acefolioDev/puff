import { mkdir, chmod, rename } from "node:fs/promises";
import { join } from "node:path";
import { homedir } from "node:os";
import type { Profile } from "../shared/types";
const dir = join(
  process.env.XDG_CONFIG_HOME || join(homedir(), ".config"),
  "puff",
);
const path = join(dir, "connections.json");
export async function profiles(): Promise<Profile[]> {
  const file = Bun.file(path);
  return (await file.exists()) ? await file.json() : [];
}
export async function saveProfile(profile: Profile) {
  const list = await profiles();
  const clean = { ...profile };
  delete clean.password;
  const next = list.filter((p) => p.id !== clean.id);
  next.push(clean);
  await mkdir(dir, { recursive: true, mode: 0o700 });
  await chmod(dir, 0o700);
  const temp = path + "." + crypto.randomUUID();
  await Bun.write(temp, JSON.stringify(next, null, 2), { mode: 0o600 });
  await chmod(temp, 0o600);
  await rename(temp, path);
}
