export function ident(value: string): string {
  if (
    typeof value !== "string" ||
    !value.length ||
    value.includes("\0") ||
    Buffer.byteLength(value) > 63
  )
    throw new Error("Invalid PostgreSQL identifier");
  return '"' + value.replaceAll('"', '""') + '"';
}
export const qualified = (schema: string, table: string) =>
  `${ident(schema)}.${ident(table)}`;
export const TYPES = [
  "text",
  "varchar(255)",
  "integer",
  "bigint",
  "numeric",
  "boolean",
  "uuid",
  "date",
  "timestamp",
  "timestamptz",
  "jsonb",
  "bytea",
] as const;
export function dataType(type: string) {
  if (!(TYPES as readonly string[]).includes(type))
    throw new Error("Unsupported column type");
  return type;
}
export function bounded(value: unknown, max: number, fallback: number) {
  const n = Number(value ?? fallback);
  if (!Number.isInteger(n) || n < 0 || n > max)
    throw new Error("Invalid pagination");
  return n;
}
