import { Database } from "./database";
import { profiles, saveProfile } from "./profiles";
import { assets } from "./assets.generated";
const db = new Database();
const token = crypto.randomUUID();
const json = (v: unknown, status = 200) =>
  new Response(
    JSON.stringify(v, (_, value) =>
      typeof value === "bigint" ? value.toString() : value,
    ),
    {
      status,
      headers: {
        "Content-Type": "application/json",
        "Cache-Control": "no-store",
      },
    },
  );
const server = Bun.serve({
  hostname: "127.0.0.1",
  port: 0,
  maxRequestBodySize: 2000000,
  idleTimeout: 255,
  async fetch(req) {
    const url = new URL(req.url);
    const origin = `http://127.0.0.1:${server.port}`;
    if (req.headers.get("host") !== `127.0.0.1:${server.port}`)
      return new Response("Invalid host", { status: 403 });
    if (url.pathname === "/api") {
      if (
        req.method !== "POST" ||
        req.headers.get("origin") !== origin ||
        req.headers.get("x-puff-token") !== token
      )
        return new Response("Forbidden", { status: 403 });
      try {
        if (Number(req.headers.get("content-length") || 0) > 2000000)
          throw new Error("Request too large");
        const { action, payload: p } = await req.json();
        const result = await db.exclusive(async () => {
          switch (action) {
            case "profiles":
              return profiles();
            case "saveProfile":
              await saveProfile(p);
              return { ok: true };
            case "connect":
              await db.connect(p);
              return { ok: true };
            case "createDatabase":
              return db.createDatabase(p.name);
            case "explorer":
              return db.explorer();
            case "page":
              return db.page(p);
            case "mutate":
              return db.mutate(p);
            case "alter":
              return db.alter(p);
            case "query":
              return db.query(p.text);
            default:
              throw new Error("Unknown API action");
          }
        });
        return json(result);
      } catch (error) {
        const e = error as any;
        return json(
          {
            error: e.message,
            code: e.code,
            detail: e.detail,
            hint: e.hint,
            position: e.position,
          },
          400,
        );
      }
    }
    if (req.method !== "GET") return new Response("Not found", { status: 404 });
    if (url.pathname === "/")
      return new Response(
        `<!doctype html><html lang="en" class="dark"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="puff-token" content="${token}"><title>Puff</title><link rel="stylesheet" href="/app.css"></head><body><div id="app"></div><script type="module" src="/app.js"></script></body></html>`,
        {
          headers: {
            "Content-Type": "text/html",
            "Cache-Control": "no-store",
            "Content-Security-Policy":
              "default-src 'none'; script-src 'self'; style-src 'self'; connect-src 'self'; img-src 'self' data:; base-uri 'none'; frame-ancestors 'none'; form-action 'none'",
          },
        },
      );
    const asset = assets[url.pathname];
    return asset
      ? new Response(asset.body, { headers: { "Content-Type": asset.type } })
      : new Response("Not found", { status: 404 });
  },
});
postMessage({ url: `http://127.0.0.1:${server.port}` });
self.onmessage = async (e: MessageEvent) => {
  if (e.data === "close") {
    await db.close();
    server.stop(true);
    process.exit(0);
  }
};
