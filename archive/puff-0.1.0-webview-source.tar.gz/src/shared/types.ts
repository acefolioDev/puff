export type Profile = {
  id: string;
  name: string;
  host: string;
  port: number;
  user: string;
  password?: string;
  database: string;
  ssl: boolean;
};
export type Column = {
  name: string;
  type: string;
  nullable: boolean;
  generated: boolean;
  primary: boolean;
};
export type Table = { schema: string; name: string };
export type Row = Record<string, unknown>;
export type Page = { rows: Row[]; columns: Column[]; keys: string[] };
