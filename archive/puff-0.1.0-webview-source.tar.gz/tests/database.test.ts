import { expect, test } from "bun:test";
import postgres from "postgres";
import { Database } from "../src/backend/database";
const enabled = !!process.env.PUFF_TEST_PG;
(enabled ? test : test.skip)(
  "real PostgreSQL: schema, composite keys, atomic changes and conflicts",
  async () => {
    const host = process.env.PUFF_TEST_PG!;
    const schema = "puff_test_" + crypto.randomUUID().replaceAll("-", "");
    const admin = postgres({
      host,
      port: 55439,
      username: process.env.USER,
      database: "postgres",
    });
    const db = new Database();
    try {
      await db.connect({
        id: "test",
        name: "test",
        host,
        port: 55439,
        user: process.env.USER!,
        database: "postgres",
        ssl: false,
      });
      await admin.unsafe(`create schema "${schema}"`);
      await db.alter({
        schema,
        table: "sample",
        action: "create",
        columns: [
          { name: "a", type: "integer", primary: true },
          { name: "b", type: "text", primary: true },
          { name: "value", type: "text" },
        ],
      });
      await db.mutate({
        schema,
        table: "sample",
        changes: [
          { kind: "insert", values: { a: 1, b: "key", value: "O'Reilly" } },
          { kind: "insert", values: { a: 2, b: "key", value: "other" } },
        ],
      });
      let page = await db.page({ schema, table: "sample" });
      expect(page.keys).toEqual(["a", "b"]);
      expect(page.rows.length).toBe(2);
      const original = JSON.parse(JSON.stringify(page.rows[0]));
      await db.mutate({
        schema,
        table: "sample",
        changes: [{ kind: "update", original, values: { value: "changed" } }],
      });
      await expect(
        db.mutate({
          schema,
          table: "sample",
          changes: [{ kind: "update", original, values: { value: "stale" } }],
        }),
      ).rejects.toThrow("Row changed");
      page = await db.page({ schema, table: "sample" });
      await expect(
        db.mutate({
          schema,
          table: "sample",
          changes: [
            {
              kind: "update",
              original: page.rows[0],
              values: { value: "rolled back" },
            },
            { kind: "insert", values: { a: 2, b: "key" } },
          ],
        }),
      ).rejects.toThrow();
      expect((await db.page({ schema, table: "sample" })).rows[0].value).toBe(
        "changed",
      );
      await db.alter({
        schema,
        table: "sample",
        action: "add",
        column: "extra",
        type: "integer",
      });
      await db.alter({
        schema,
        table: "sample",
        action: "rename",
        column: "extra",
        name: "renamed",
      });
      await db.alter({
        schema,
        table: "sample",
        action: "type",
        column: "renamed",
        type: "text",
      });
      await db.alter({
        schema,
        table: "sample",
        action: "drop",
        column: "renamed",
      });
      const row = (await db.page({ schema, table: "sample" })).rows[0];
      await db.mutate({
        schema,
        table: "sample",
        changes: [{ kind: "delete", original: row }],
      });
      expect((await db.page({ schema, table: "sample" })).rows.length).toBe(1);
    } finally {
      await db.close();
      await admin.unsafe(`drop schema if exists "${schema}" cascade`);
      await admin.end();
    }
  },
  20000,
);

(enabled ? test : test.skip)(
  "database creation quotes names and reports duplicate and privilege errors",
  async () => {
    const host = process.env.PUFF_TEST_PG!;
    const admin = postgres({
      host,
      port: 55439,
      username: process.env.USER,
      database: "postgres",
    });
    const db = new Database();
    const name = "puff_db_" + crypto.randomUUID().slice(0, 8) + '"quoted';
    const role = "puff_limited_" + crypto.randomUUID().replaceAll("-", "");
    const quote = (v: string) => '"' + v.replaceAll('"', '""') + '"';
    try {
      await db.connect({
        id: "test",
        name: "test",
        host,
        port: 55439,
        user: process.env.USER!,
        database: "postgres",
        ssl: false,
      });
      await db.createDatabase(name);
      expect(
        (await admin`select datname from pg_database where datname=${name}`)
          .length,
      ).toBe(1);
      await expect(db.createDatabase(name)).rejects.toThrow("already exists");
      await expect(db.createDatabase("")).rejects.toThrow("Invalid");
      await admin.unsafe(`create role ${quote(role)} login nocreatedb`);
      await db.connect({
        id: "limited",
        name: "limited",
        host,
        port: 55439,
        user: role,
        database: "postgres",
        ssl: false,
      });
      await expect(db.createDatabase("puff_forbidden")).rejects.toThrow(
        "permission denied",
      );
    } finally {
      await db.close();
      await admin.unsafe(`drop database if exists ${quote(name)}`);
      await admin.unsafe(`drop role if exists ${quote(role)}`);
      await admin.end();
    }
  },
  20000,
);
