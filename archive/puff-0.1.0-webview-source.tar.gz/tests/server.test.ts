import { expect, test } from "bun:test";
const enabled = process.env.PUFF_TEST_HTTP === "1";
(enabled ? test : test.skip)(
  "loopback API requires token, origin, host and POST",
  async () => {
    const worker = new Worker(
      new URL("../src/desktop/server.worker.ts", import.meta.url).href,
    );
    try {
      const url = await new Promise<string>((resolve, reject) => {
        worker.onmessage = (e) => resolve(e.data.url);
        worker.onerror = reject;
      });
      const response = await fetch(url);
      const html = await response.text();
      expect(response.headers.get("content-security-policy")).toContain(
        "frame-ancestors 'none'",
      );
      const token = html.match(/name="puff-token" content="([^"]+)"/)![1];
      expect((await fetch(url + "/app.js")).status).toBe(200);
      expect(
        (await fetch(url + "/api", { method: "POST", body: "{}" })).status,
      ).toBe(403);
      expect(
        (
          await fetch(url + "/api", {
            method: "POST",
            headers: { origin: "https://evil.example", "x-puff-token": token },
            body: "{}",
          })
        ).status,
      ).toBe(403);
      const allowed = await fetch(url + "/api", {
        method: "POST",
        headers: {
          origin: url,
          "x-puff-token": token,
          "content-type": "application/json",
        },
        body: JSON.stringify({ action: "explorer" }),
      });
      expect(allowed.status).toBe(400);
      expect((await allowed.json()).error).toBe("Connect to a database first");
    } finally {
      worker.terminate();
    }
  },
  10000,
);
