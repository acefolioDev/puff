import { describe, expect, test } from "bun:test";
import { ident, qualified, dataType, bounded } from "../src/backend/sql";
describe("SQL boundaries", () => {
  test("identifiers cannot escape quotes", () => {
    expect(qualified("public", 'x"; drop table users;--')).toBe(
      '"public"."x""; drop table users;--"',
    );
  });
  test("invalid identifiers fail", () => {
    for (const value of ["", "a\0b", "x".repeat(64)])
      expect(() => ident(value)).toThrow();
  });
  test("types cannot contain SQL", () => {
    expect(() => dataType("text; drop table x")).toThrow();
    expect(dataType("jsonb")).toBe("jsonb");
  });
  test("pagination is bounded", () => {
    expect(bounded(100, 500, 50)).toBe(100);
    for (const value of [-1, 1.1, 501, "NaN"])
      expect(() => bounded(value, 500, 50)).toThrow();
  });
});
